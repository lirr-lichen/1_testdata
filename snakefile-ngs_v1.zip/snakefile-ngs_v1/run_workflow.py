import os, sys
import re
import argparse
import pandas as pd
import multiprocessing
import subprocess
import json
import datetime
import time
from utilties.config_generate import NGS_generate, samples_json_generate, samplesheet_length, config_yaml_generate, samples_check, samples_information, runinformation
from utilties.bsub_json import bsub_json
from utilties.PBS import qsub_json

## Define the input parameters
def args_input():
    parser = argparse.ArgumentParser(description='This is a pipeline built for the Single end NGS analysis. \
    refer to the nerve system metegenome detection. The Configs files contains the significant softwares_database configuration json files. \
    The NGS json file generated based on the input args, it contains the config information in the analysis(like workdir, output directory etc)\
    , in default, then run snakemake separately.')
    parser.add_argument('-W','--workdir', help='path of working directory', type=str, default='/gpfsdata/users/zhangyan/snakefile-test')
    parser.add_argument('-I', '--rawdir', help='path of local raw data directory contains the raw data', type=str, required=True)
#    parser.add_argument('-C','--config', help='A config xlsx file contained all the information needed for samples.', type=str, required=True)
    parser.add_argument('-O','--outdir', help='output directory to save final results', type=str, required= True)
    parser.add_argument('-R','--reportdir', help='report directory to save report results', type=str, required= True)
    parser.add_argument("--workflow", help = "The analysis workflow directory, it contains the whole pipeline.", type = str, default = "/gpfsdata/users/zhangyan/snakefile-test")
#    parser.add_argument('-P','--process', help='set up the process in the analysis', type=int, default=3)
    parser.add_argument("--check", help = "run a check of the rawdir samples compare to the samplesheet file, if no match, report errors.", action = "store_true", default=False)
#    parser.add_argument('-T','--task', help='set the number of synchronously run in the analysis', type=int, default=3)
    parser.add_argument("--cores", help = "The cores used in the analysis.", type = str, default= "24")
    parser.add_argument("--IC", help="the taxid of IC in the analysis, default as 10710, 329852, 1921008 now.",action="append", nargs="+", type=str, default=["10710", "329852", "1921008"])
    parser.add_argument("--samplesheet", help = "the samplesheet csv file for the analysis.", type= str, required=True)
#    parser.add_argument("--cluster",  help = "The cluster system for the pipeline, include LSF and PBS, default as LSF.", choices=["LSF", "PBS"], default= "LSF")
#    parser.add_argument("--runinfor", help = "A runinfor json file to save the run information for report..", type= str, required=True)
    parser.add_argument('--version', action='version', version='%(prog)s (version 1)')
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
    args = parser.parse_args()
    return args
def main():
    args = args_input()
    if not os.path.isdir(args.workdir):
        os.mkdir(args.workdir)
        print ("The work directory no present, create it now.")
    if not os.path.isdir(args.outdir):
        os.mkdir(args.outdir)
        print("The output directory no present, create it now.")
    if not os.path.isdir(args.reportdir):
        os.mkdir(args.reportdir)
        print("The report directory no present, create it now.")    
#    subprocess.Popen(['mkdir', args.workdir])
#    subprocess.Popen(['mkdir', args.outdir])
    start_time = time.strftime("%Y-%m-%d %H:%M",time.localtime())
    #-- add a time in the workdir and outdir
    samples_file = os.path.join(args.workdir, "samples.json")
    run_sample = subprocess.Popen(["touch", samples_file])
    run_sample.communicate()
    samples_json_generate(args.rawdir, samples_file)
    print ("Finish the samplelist json file generate.")
    sample_infor = os.path.join(args.outdir, "sample_information.tsv")
#    sample_infor2 = os.path.join(args.outdir, "sample_information2.tsv")
    run1 = subprocess.Popen(["touch", sample_infor])
#    run2 = subprocess.Popen(["touch", sample_infor2])
    run1.communicate()
#    run2.communicate() # make sure the execute finished
    Runid = samples_information(args.samplesheet,sample_json = samples_file, output = sample_infor)
    runiddir = os.path.join(args.reportdir, Runid)
    alldir = os.path.join(runiddir, "all")
    if not os.path.isdir(runiddir):
        os.mkdir(runiddir)
    if not os.path.isdir(alldir):
        os.mkdir(alldir)
        print ("The report runid and all directory no present, create it now.")
    Length = "75"
    #-- add a check between the samplelist.json and samplesheet file
#    if args.samplesheet:
#        Length = samplesheet_length(args.samplesheet)
#    print ("Finish the samplesheet file read, and extract the reads length information.")
    NGS_json = os.path.join(args.workdir, "NGS.json")
    run_NGS = subprocess.Popen(["touch", NGS_json])
    run_NGS.communicate()
    NGS_generate(args.workdir, args.outdir, alldir, runid = Runid, length = Length, final = NGS_json)
    print ("Finished the NGS.json config file generate.")
    config_yaml = os.path.join(args.workdir, "config.yaml")
    run_config = subprocess.Popen(["touch", config_yaml])
    run_config.communicate()
    config_yaml_generate(samples_file, NGS_json, args.workflow, config_yaml)
    print( "Finished the config yaml file generate in the workdir.")

    runinformation(sample_infor, os.path.join(runiddir, "runinfo.json"))
    if args.check and args.samplesheet:
        samples_check_result = os.path.join(args.outdir, "samples_check.tsv")
        run_check = subprocess.Popen(["touch", samples_check_result])
        run_check.communicate()
        samples_check(samples_file, sample_infor, samples_check_result)
    print ("Finished the config file information extract.")
#    if args.cluster == "LSF":
#        bsub = bsub_json(workdir = args.workdir)
#        bsub_para = 'bsub -L {} -J {} -n {} -o {} -e {}'.format(bsub["execute"], bsub["name"], bsub["nCPUs"], bsub["output"], bsub["error"])
#        job = subprocess.Popen("{} snakemake --cores {} --snakefile {} --configfile {} --restart-times 1 --rerun-incomplete >{} 2>&1".format(bsub_para, args.cores, os.path.join(args.workflow, "Snakefile"), config_yaml, os.path.join(args.workdir, "run.log")), shell= True)
#        job.communicate()
#    if args.cluster == "PBS":
#        qsub = qsub_json(workdir= args.workdir)
#        qsub_para = "qsub -N {} -o {} -e {} -l {} -l {} -l {}".format(qsub["name"], qsub["output"], qsub["error"], qsub["node"], qsub["memory"], qsub["walltime"])
#        job = subprocess.Popen("{} snakemake --cores {} --snakefile {} --configfile {} --restart-times 1 --rerun-incomplete >{} 2>&1".format(qsub_para, args.cores, os.path.join(args.workflow, "Snakefile"), config_yaml, os.path.join(args.workdir, "run.log")))
#        job.communicate()

    #subprocess.Popen("snakemake --cluster \"{}\" --cores {} --snakefile {} --configfile {} > {} 2>&1".format(bsub_para, bsub["nCPUs"], os.path.join(args.workflow, "Snakefile"), config_yaml, os.path.join(args.workdir, "run.log")), shell= True)
#    subprocess.Popen("{} snakemake --cores {} --snakefile {} --configfile {} --rerun-incomplete > {} 2>&1".format(bsub_para, bsub["nCPUs"], os.path.join(args.workflow, "Snakefile"), config_yaml, os.path.join(args.workdir, "run.log")), shell= True)
#    if args.run:
#    subprocess.Popen("snakemake --cores {} --snakefile {} --configfile {}".format(args.cores, os.path.join(args.workflow, "Snakefile"), config_yaml), shell= True)
#    if args.blast:
#    subprocess.Popen("snakemake --cores {} --snakefile {} --configfile {}".format(args.cores, os.path.join(args.workflow, "Snakefile_blast"), config_yaml), shell= True)

    end_time = time.strftime("%Y-%m-%d %H:%M", time.localtime())
    print ("Finished the snakemake configs at {}, now it could run.".format(end_time))

if __name__ == '__main__':
    main()
