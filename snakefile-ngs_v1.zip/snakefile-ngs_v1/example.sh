## QC and reads filter part
fastp -i /gpfsdata/home/ngsdata/200528_NDX550264_0057_AHJFLLBGXB/CNS/mCNS1820200527734L_S3_R1_001.fastq.gz \
-l 75 -e 30 -w 8 \
--adapter_sequence=AGATCGGAAGAGCACACGTCTGAACTCCAGTCA \
--adapter_sequence_r2=AGATCGGAAGAGCGTCGTGTAGGGAAAGAGTGT \
-o /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc1.fastq \
-j /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc1.json \
-h /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc1.html \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc1.log 2>&1

seqkit rmdup -s -i -j 8 \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc1.fastq \
-o /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc2.fastq \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc2.log 2>&1

cutadapt -b AGATCGGAAGAGCACACGTCTGAACTCCAGTCA -b ATCTCGTATGCCGTCTTCTGCTTG -m 75 -j 8 --discard-trimmed \
-o /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc3.fastq \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc2.fastq \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc3.log 2>&1

## Rmhost part
/gpfsdata/users/liangxz/software/kraken2/kraken2 \
--db /gpfsdata/users/liangxz/work/4.Respiratory_pathogen/23.NTv5_seqid2taxid/3.microbial_nt_db/human \
--report /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.rmhost.report \
--output /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.rmhost.kraken \
--unclassified-out /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap1.fastq \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC/mCNS1820200527734L.qc3.fastq \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.rmhost1.log 2>&1

centrifuge  /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap1.fastq \
-q --quiet -x /gpfsdata/users/fangwei/pipeline/db/host_centrifuge/hg38 \
--un /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap2.fastq \
-p 4 \
-S /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap2.log1 \
--report-file /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap2.log2 \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.rmhost2.log 2>&1

bwa mem /gpfsdata/users/fangwei/pipeline/db/host_bwa/hg38.index  \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap2.fastq \
-t 4 | grep -v "@" - |awk -F"\t" '{if($3 == "*") print("@"$1"\n"$10"\n+\n"$11)}' \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap3.fastq \
2> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.rmhost3.log \

bowtie2 --no-head --very-sensitive -x /gpfsdata/users/fangwei/pipeline/db/host_bowtie2/hg38  \
-U /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap3.fastq \
-p 4 | grep -v "@" - |awk -F"\t" '{if($3 == "*") print("@"$1"\n"$10"\n+\n"$11)}' \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap4.fastq \
2> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.rmhost4.log

seqkit fq2fa /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap4.fastq \
-o /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap4.fasta \
-j 4 \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.seqkit.rmhost.log 2>&1

## kraken2 part
# IC kraken2
/gpfsdata/users/liangxz/software/kraken2/kraken2 \
--db  /gpfsdata/users/liangxz/work/20.NGS/db/kraken2 \
--report /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.IC.report \
--output /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.IC.kraken \
--unclassified-out /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.IC.unclassified.fastq \
--threads 12 \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap4.fastq \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.kraken.IC.log 2>&1
# microbial kraken2
/gpfsdata/users/liangxz/software/kraken2/kraken2 \
--db /gpfsdata/users/liangxz/work/4.Respiratory_pathogen/23.NTv5_seqid2taxid/3.microbial_nt_db/kraken2 \
--output /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.kraken \
--report /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.report \
--unclassified-out /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbil.unclassified.fastq \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.IC.unclassified.fastq \
--threads 12 \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.kraken2.microbial.log 2>&1

# microbial kmer optimization
perl /gpfsdata/users/zhangyan/snakefile-test/scripts/kmer_optimization.pl \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.kraken \
0.5 \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.flt.kraken \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.flt.log 2>&1
# microbial kmer kraken report
/gpfsdata/apps/bin/krakenuniq-report \
--db /gpfsdata/users/liangxz/work/4.Respiratory_pathogen/23.NTv5_seqid2taxid/3.microbial_nt_db/kraken \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.flt.kraken \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.flt.report \
2> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.flt.report.log
# microbial bracken
python3 /gpfsdata/users/liangxz/software/Bracken/src/est_abundance.py \
-k /gpfsdata/users/liangxz/work/4.Respiratory_pathogen/23.NTv5_seqid2taxid/3.microbial_nt_db/kraken2/database150mers.kmer_distrib \
-i /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.flt.report \
-l S -t 12 \
-o /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.flt.bracken \
> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.flt.bracken.log 2>&1

## IC bracken and results merge
python3 /gpfsdata/users/zhangyan/snakefile-test/scripts/bracken-merge.py \
--input /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.IC.report \
--microbial /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.microbial.flt.bracken \
--kmer /gpfsdata/users/liangxz/work/20.NGS/db/kraken2/database150mers.kmer_distrib \
--software /gpfsdata/users/liangxz/software/Bracken/src/est_abundance.py \
--IC /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.IC.bracken \
--output /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.final.bracken \
--threads 12 \
--merge /gpfsdata/users/zhangyan/nerve_ngs/snakefile-test/scripts/merge_bracken.pl \
>/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken/mCNS1820200527734L.merge.bracken.log 2>&1
# 就是简单的封装了一下这部分，如果 kraken IC.report 内容为空，直接创建一个空的IC的bracken， 然后进行microbial的bracken， 结果整合为final.bracken
## blast part
# IC blast
/gpfsdata/apps/source/ncbi-blast-2.10.0+/bin/blastn \
-task megablast -evalue 1e-5 -word_size 28 -gapopen 0 -gapextend 2 -max_target_seqs 10 -penalty -4 -reward 1 -max_hsps 1 \
-outfmt "6 qseqid qlen qstart qend saccver slen sstart send bitscore staxid ssciname sskingdom length pident" \
-query /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap4.fasta \
-db /gpfsdata/users/liangxz/work/4.Respiratory_pathogen/23.NTv5_seqid2taxid/3.microbial_nt_db/IC/IC \
-num_threads 8 \
-out /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.unmap4.IC.blast \
2> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.IC.blast.log
# generate fasta file without IC blast reads
bash /gpfsdata/users/zhangyan/snakefile-test/scripts/blast.sh  \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap4.fasta \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.unmap4.IC.blast \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.unmap5.fasta \
2> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.unmap5.fasta.log
# microbial blast
/gpfsdata/apps/source/ncbi-blast-2.10.0+/bin/blastn \
-task megablast -evalue 1e-5 -word_size 28 -gapopen 0 -gapextend 2 -max_target_seqs 10 -penalty -4 -reward 1 -max_hsps 1 \
-outfmt "6 qseqid qlen qstart qend saccver slen sstart send bitscore staxid ssciname sskingdom length pident" \
-query /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.unmap5.fasta \
-db /gpfsdata/users/liangxz/work/4.Respiratory_pathogen/23.NTv5_seqid2taxid/3.microbial_nt_db/blast/microbial_nt \
-num_threads 8 \
-out /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.unmap5.NT0.blast \
2> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.NT.blast.log
# merge and extract the blast results
perl /gpfsdata/users/zhangyan/snakefile-test/scripts/blast_addSpecies_abun.pl \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.unmap4.IC.blast \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.unmap5.NT0.blast \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.species.tsv \
/gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.abundance.tsv \
2> /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast/mCNS1820200527734L.abundance.log

## chimera
/gpfsdata/users/hl/mysoftware/vsearch-2.14.1-linux-x86_64/bin/vsearch \
--uchime_ref /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost/mCNS1820200527734L.unmap4.fasta \
--db /gpfsdata/users/zhangyan/NGS_database_20200510/reference/IC.fasta \
--threads 6
--chimera /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/chimera/mCNS1820200527734L.chimera.fasta \
--log /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/chimera/mCNS1820200527734L.chimera.log
## statistics
# kraken2 result statistics
python3 /gpfsdata/users/zhangyan/snakefile-test/scripts/statistics_kraken.py \
--QC /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC \
--rmhost /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost \
--kraken /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken \
--chimera /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken \
--output /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/statistics_kraken.xlsx
# blast result statistics
python3 /gpfsdata/users/zhangyan/snakefile-test/scripts/statistics_blast.py \
--QC /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/QC \
--rmhost /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/rmhost \
--blast /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/blast \
--chimera /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/kraken \
--output /gpfsdata/users/zhangyan/nerve_ngs/20200528_analysis/statistics_blast.xlsx