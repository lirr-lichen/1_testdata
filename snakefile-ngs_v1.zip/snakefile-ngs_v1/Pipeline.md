# Pipeline

## Rawdata

### split

### transfer

## Prepare

### Run a check of rawdata according to config file

### Generate the config yamls

- samples.json
- NGS.json

### workdir

### output

## QC and filter

### Fastp

### Seqkit

### cutadapt

## Remove host

### kraken2

### Centrifuge

### bwa

### bowtie

## kraken2

### IC kraken

### microbial kraken

### kmer-score-filter

### microbial_flt kraken report

### IC bracken

### microbial bracken

### results merge and extract

## Results

### results arrange

### statistics

## blast 

### IC blast

### generate fasta without IC reads

### microbial NT blast

### results merge and extract

*XMind - Trial Version*