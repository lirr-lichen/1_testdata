<<<<<<< HEAD
# Ngs_pipeline for the single end metagenome NGS analysis. 
# Based on snakemake module, build the pipeline.
# Our server architected of LSF, so the pipeline will generate the lsf file in analysis. But now we should tranfer the pipeline to a PBS server, so we add the PBS mode.
## structure and demo(Xmind)
## Through Dingding to send message to the related cooperaters
## input
### NGS fastq files
### samplesheet file
### workflow directory(the project itself)
### snakemake cores(defaulted)
### workdir 
### outputdir
### server, LSF or PBS
### python3 run_workflow.py --help(could generate the method to use it).
## reference directory and files(finished config it in json files.)
## log, warnings and errors(control it in the earlier step)(In progress.)
## output
## results
## Some fixed parameters extracted from snakefile, then arrange them to a config file(Finished)
## the snakefile could be configured according to it(Finished).
## The running method


# Development in the next stage.
## Detect CPU and memory, then setup the cores and memory used for it in each step analysis, to ensure no interrupt during the process
## database update
## algorithm upgrade
## report version control

# Development in the future
## docker/singularity packaing the dependencies, include softwares(especially kraken2)
## the related database built locally
## 
=======
# snakemake-ngs_v1
This is a project for Metagenome NGS test.
>>>>>>> End
