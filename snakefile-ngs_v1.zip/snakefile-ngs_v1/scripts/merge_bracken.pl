#!/usr/bin/perl

my($in1, $in2, $out) = @ARGV;

open OUT,">$out"|| die;
print OUT "name\ttaxonomy_id\taxonomy_lvl\tkraken_assigned_reads\tadded_reads\tnew_est_reads\tabun_total_reads(%)\n";

my (%taxa, %read, %add, %all, %per);
&get_bracken($in1, \%taxa, \%read, \%add, \%all);
&get_bracken($in2, \%taxa, \%read, \%add, \%all);

foreach my $key( sort{$read{$b} <=> $read{$a}} keys %read){
    my $total  = $read{$key} + $add{$key};
    my $per    = sprintf "%.5f", 100 * $total/$all{"all"}; # changed # changed the number of significant figures from 2 to 5
    $per{$key} = $per;
}

foreach my $key1(sort{$per{$b} <=> $per{$a}} keys %per){
    my $total  = $read{$key1} + $add{$key1};
    print OUT "$taxa{$key1}\t$read{$key1}\t$add{$key1}\t$total\t$per{$key1}\n";
}
close OUT;

#########
sub get_bracken{
    my($file, $taxa, $read, $add, $all) = @_;
    open TMP, $file || die;
    while(<TMP>){
        chomp;
        next if /^name/;
        my @arr = split(/\t/);

        my $name = $arr[0];
        $$taxa{$name}  = $arr[0]."\t".$arr[1]."\t".$arr[2];
        $$read{$name} += $arr[3];
        $$add{$name}  += $arr[4];
        $$all{"all"}  += $arr[5];
    }
}
