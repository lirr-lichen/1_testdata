import os, sys
import pandas as pd
import numpy as np
#from pandas import DataFrame
import re
import argparse
import subprocess
import time
import copy

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for NGS result filter and arrange.')
    parser.add_argument('--input', help='A input NGS result, the BigMatrix sheet will be used.', type=str, required = True)
    parser.add_argument('--pathogen', help='A pathogen file needed in the analysis.', type=str, default="/gpfsdata/users/zhangyan/NGS_database_20200510/pathogen_list/pathogen.tsv")
    parser.add_argument("--taxDB", help = "A taxDB file contains the taxid_species information.", type = str, default="/gpfsdata/users/zhangyan/NGS_database_20200510/reference/taxDB.tsv")
    parser.add_argument('--origin', help='An output file to save the original result, default as xlsx.', type=str, required = True)
    parser.add_argument('--output1', help='An output file to save demo results, default as xlsx format.', type=str, required = True)
    parser.add_argument('--output2', help='An output file to save final results, default as xlsx format.', type=str,required=True)
#    parser.add_argument('--chimera', help="A list of chimera files.", type=str, nargs= "+")
#    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args
def filter_part1(data, MicroSum = 100, abundance = 0.001, filter1 = 100):
    data = copy.deepcopy(data)
    data.rename(columns = {"rlaPct" : "abundance", "species_nano" : "species", "mis_algn2": "mis_align2"}, inplace= True)
    data["MicroSum_filter"] = 1
    data.loc[data["MicroSum"] < MicroSum, "MicroSum_filter"] = 0
    data["abundance_filter"] = 0
    data.loc[(data["SampleType"] == "CSF") & (data["abundance"] >= 0.0001), "abundance_filter"] = 1
    data.loc[(data["SampleType"] == "respiratory") & (data["abundance"] >= 0.0001), "abundance_filter"] = 1
    data.loc[(data["SampleType"] == "urinary") & (data["abundance"] >= abundance), "abundance_filter"] = 1
    data["brd_value"] = data["brd_leak2"] / data["RPM"]
    data["misalign_value"] = data["mis_align2"] / data["RPM"]
    data["brd_filter"] = 1
    data["misalign_filter"] = 1
    data.loc[data["brd_value"] > filter1, "brd_filter"] = 0
    data.loc[data["misalign_value"] > filter1, "misalign_filter"] = 0
    data["fold"] = (data["RPM"] / data["RPM_back"]) / (data["RPM_IC"] / data["RPM_BKIC"])
    data["foldIC"] = data["RPM_IC"] / data["RPM"]
    data["foldBK"] = data["RPM_back"] / data["RPM"]
    data["fold_filter"] = 0
    data.loc[((data["fold"].isnull()) | (data["fold"] > 2)) & (data["foldBK"] < 0.2) & (data["foldIC"] < 10) & (data["SampleType"] != "CSF"), "fold_filter"] = 1
    data.loc[((data["fold"].isnull()) | (data["fold"] > 2)) & (data["foldBK"] < 1.0) & (data["foldIC"] < 100) & (data["species"] == "Mycobacterium tuberculosis"), "fold_filter"] = 1
    data.loc[(data["foldIC"] < 10) & (data["species"] != "Mycobacterium tuberculosis") & (data["SampleType"] == "CSF"), "fold_filter"] = 1
    data = data[["mk", "RunID", "sampleID", "SampleType","libType", "taxid", "superkingdom", "genus", "species", "reads", "abundance", "MicroSum",\
                               "reads_back","reads_IC","reads_BKIC","RPM","RPM_back","RPM_IC","RPM_BKIC", "RPMSum","BM_rank","brd_leak1",\
                               "mis_algn1","brd_leak2", "mis_align2", "brd_value", "misalign_value", "fold", "foldIC", "foldBK", \
                 "MicroSum_filter", "abundance_filter", "brd_filter", "misalign_filter", "fold_filter"]]
    return (data)
#def filter_background():
#    return (True)
#def pathogen_tag(data, pathogen):
#    pathogen = pd.read_csv(pathogen, sep = "\t")
#    pathogen1 = copy.deepcopy(pathogen[["type", "species", "Genus_Chinese", "species_Chinese"]])
#    pathogen1.rename(columns = {"type" : "SampleType"}, inplace= True)
#    pathogen1["pathogen_filter"] = 1
#    result = pd.merge(data, pathogen1, on = ["SampleType", "species"], how= "left")
#    result["pathogen_filter"] = result["pathogen_filter"].fillna(0)
#    result = result[["mk", "RunID", "sampleID", "SampleType","libType", "taxid", "superkingdom", "genus","Genus_Chinese", "species", "species_Chinese","reads", "abundance", "MicroSum",\
#                               "reads_back","reads_IC","reads_BKIC","RPM","RPM_back","RPM_IC","RPM_BKIC", "RPMSum","BM_rank","brd_leak1",\
#                               "mis_algn1","brd_leak2", "mis_align2", "brd_value", "misalign_value", "fold", "foldIC", "foldBK", \
#                 "MicroSum_filter", "abundance_filter", "brd_filter", "misalign_filter", "fold_filter", "pathogen_filter"]]
#    return (result)
def pathogen_tag(data, taxDB, pathogen):
    pathogen = pd.read_csv(pathogen, sep = "\t")
    taxdb = pd.read_csv(taxDB, sep = "\t", usecols=["taxid", "species"])
    del data["species"]
    data = pd.merge(data, taxdb[["taxid", "species"]], on = "taxid", how = "left")
    pathogen1 = copy.deepcopy(pathogen[["type", "species"]])
    pathogen1.rename(columns = {"type" : "SampleType"}, inplace= True)
    pathogen1["pathogen_filter"] = 1
    result = pd.merge(data, pathogen1, on = ["SampleType", "species"], how= "left")
    result["pathogen_filter"] = result["pathogen_filter"].fillna(0)
    result = result[["mk", "RunID", "sampleID", "SampleType","libType", "taxid", "superkingdom", "genus", "species", "reads", "abundance", "MicroSum",\
                               "reads_back","reads_IC","reads_BKIC","RPM","RPM_back","RPM_IC","RPM_BKIC", "RPMSum","BM_rank","brd_leak1",\
                               "mis_algn1","brd_leak2", "mis_align2", "brd_value", "misalign_value", "fold", "foldIC", "foldBK", \
                 "MicroSum_filter", "abundance_filter", "brd_filter", "misalign_filter", "fold_filter", "pathogen_filter"]]
    return (result)
def main():
    args = parse_input()
    data = pd.read_excel(args.input, sheet_name="BigMatrix")
    # reads_IC	reads_BKIC	RPM	RPM_back	RPM_IC	RPM_BKIC RPMSum	rlaPct	BM_rank	brd_leak1	mis_algn1	brd_leak2	mis_algn2
    data = copy.deepcopy(data[["mk", "RunID", "sampleID", "SampleType", "libType", "taxid", "superkingdom", "genus", "species_nano", "reads", "rlaPct", "MicroSum",\
                               "reads_back","reads_IC","reads_BKIC","RPM","RPM_back","RPM_IC","RPM_BKIC", "RPMSum","BM_rank","brd_leak1",\
                               "mis_algn1","brd_leak2", "mis_algn2"]])
    data.dropna(subset=["species_nano"], inplace = True)
    df = filter_part1(data = data)
    result = pathogen_tag(df, args.taxDB,args.pathogen)
    result.to_excel(args.origin, index = False)
    output = result[["mk", "RunID", "sampleID", "SampleType","libType", "taxid", "superkingdom", "genus","species","reads", "abundance", "MicroSum", \
                     "MicroSum_filter", "abundance_filter", "brd_filter", "misalign_filter", "fold_filter", "pathogen_filter"]]
    output.rename(columns= {"MicroSum": "微生物总reads数", "MicroSum_filter": "微生物总reads数过滤", "abundance_filter": "菌种丰度筛选", \
                            "brd_filter": "同一批次污染排查", "misalign_filter": "同属菌种错误比对排查", "fold_filter": "NC菌种进一步筛选", "pathogen_filter": "致病菌列表筛选"}, inplace= True)
    writer = pd.ExcelWriter(args.output1, engine="openpyxl")
    output = copy.deepcopy(output)
    for i in sorted(output[output["sampleID"].notnull()]["sampleID"].tolist()):
        df = copy.deepcopy(output[output["sampleID"] == i])
        df.sort_values(by = "abundance", ascending=False, inplace= True)
  #      df.reset_index(inplace = True)
 #       df.loc[0] = ["##批次编号合并订单编号", "批次编号", "订单编号", "样本类型", "文库类型", "taxid", "界", "属", "物种", "序列数", \
 #                    "相对丰度", "总的微生物reads数", "所有微生物总reads数水平过滤(这个是针对整个样本水平的, 通过为1)", "菌种丰度水平的过滤(通过为1)", \
 #                    "同一批次污染排查(通过为1)", "同属不同菌种错误比对排查(通过为1)", "存在于NC的菌种进一步筛选(通过为1)", "致病菌列表筛选(存在于致病菌列表为1)"]
 #       df.sort_index(inplace=True)
        if type(i) == float:
            df.to_excel(writer, sheet_name=str(int(i)), index=False)
        else:
            df.to_excel(writer, sheet_name= i , index=False)
    writer.save()
    writer.close()
    final = result[(result["MicroSum_filter"] == 1) & (result["abundance_filter"] == 1) & \
                   (result["brd_filter"] == 1) & (result["misalign_filter"] == 1) & \
                   (result["fold_filter"] == 1) & (result["pathogen_filter"] == 1)][["mk", "RunID", "sampleID", "SampleType","libType", "taxid", "superkingdom", "genus","species","reads", "abundance", "MicroSum"]]
#    final.rename(columns= {"MicroSum": "微生物总reads数"}, inplace= True)
    final.to_excel(args.output2, index = False)
    return("Finished the analysis.")
if __name__ == "__main__":
    main()

