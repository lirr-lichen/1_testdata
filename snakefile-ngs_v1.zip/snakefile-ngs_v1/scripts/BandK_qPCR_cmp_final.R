
#some species are always together, maybe the same thing.
options(java.parameters = "-Xmx16000m")
options(scipen=1000);options(warn=-1);
suppressMessages(library(magrittr));
suppressMessages(library(data.table));
suppressMessages(library(parallel));
suppressMessages(library(GenomicRanges));
suppressMessages(library(ggplot2));
suppressMessages(library(xlsx));
#source(			"/gpfsdata/users/hl/projects/06.mNGS_CNS/BIN/sub_statistics_reorganize3.R")
#inputF1		=	"/gpfsdata/users/hl/projects/06.mNGS_CNS/03.cutoff/All_samples_information_qpcr.txt"
#inputF21	=	"/gpfsdata/users/zhangyan/nerve_ngs/kraken_results/kraken_species.tsv"; #braken results
#inputF22	=	"/gpfsdata/users/zhangyan/nerve_ngs/kraken_results/kraken_origin.tsv";	#kraken results
#inputF3		=	"/gpfsdata/users/hl/projects/06.mNGS_CNS/03.cutoff/pathogen.tsv"
#output1		=	"/gpfsdata/users/hl/projects/06.mNGS_CNS/03.cutoff/"
args=commandArgs(T)
source(args[1])
inputF1 = args[2]
inputF21 = args[3]
inputF22 = args[4]
inputF3 = args[5]
output1 = args[6]
output2 = args[7]
output3 = args[8]
################################	formating the clinical information
VR				=	fread(inputF1,sep="\t",head=T);
#my_fuc			=	function(x){y=unlist(strsplit(x,split=";"));y=y[1];y}
#VR[,RunID		:=	batchID,];
#VR[,batchID		:=	NULL,]
#VR[,sampleID	:=	originid];
#VR[,originid	:=	NULL]
#VR[,libID		:=	samples]
#VR[,samples		:=	NULL]
#VR[,SampleType	:=	type]
#VR[,type		:=	NULL]
#VR$libType		=	VR$library
#VR[,"library"	:=	NULL]
VR[,Culture_results:=	""]
#VR[,culture		:=	NULL]
#VR[libID=="mCNS1820200608828L",sampleID	:= "waterRNAIC"]
#VR[libID=="mCNS1820200608828L",SampleType:= "water_RNAIC"]
#VR[libID=="mCNS1820200608828L",libType	:= "RNA"]
VR [, PCRpos := ""]
VR [, PCRneg := ""]
VR				=	VR[!SampleType %chin% c('water','water_DNAIC_RNAIC','host_DNAIC','host_RNAIC'),]
########	one sample one output, one batch one background
#check if same sample has different culture results or PCR pos
tmp1			=	copy(VR);
tmp1[,mk		:=	paste(RunID,sampleID,libType,sep="_"),by=libID];
tmp1[,t1		:=	head(Culture_results,1),by=mk];
tmp1[,t2		:=	tail(Culture_results,1),by=mk];
stopifnot(nrow(tmp1[t1!=t2])==0);#check if same sample has different culture results
tmp1[,t1		:=	head(PCRpos,1),by=mk];
tmp1[,t2		:=	tail(PCRpos,1),by=mk];
stopifnot(nrow(tmp1[t1!=t2])==0);#check if same sample has different PCR pos
tmp1[,c('t1','t2'):=	NULL,];
#merge different library resulst to sample level.
tmp2			=	copy(VR);
tmp2[,mk		:=	paste(RunID,sampleID,sep="_"),by=libID];
tmp3			=	tmp2[,head(.SD[,c('RunID','sampleID','SampleType','Culture_results','PCRpos','PCRneg')],1),by=mk]
tmp3			=	tmp3[!grepl('water',SampleType)]
setkey(tmp3,mk)
mks				=	tmp3$mk %>% sort %>% unique
CUL_out			=	lapply(mks,sub_format_VR_cul,VR=tmp3) %>% rbindlist
PCR_out			=	lapply(mks,sub_format_VR_pcr,VR=tmp3) %>% rbindlist
stopifnot(nrow(PCR_out[pcrans=="wrong",])==0)
VR_final1		=	copy(tmp3)
################################    formating the pathogen information
PATHO			=	fread(inputF3,sep="\t",head=T);
PATHO[,SampleType:=	type]
PATHO[,patho	:=	species]
PATHO[,libType	:=	classify]
PATHO[,type		:=	NULL]
PATHO[,species	:=	NULL]
PATHO[,classify	:=	NULL]
################################    formating the taxonomial information
ALIGN			=	fread(inputF21,sep="\t",head=T,nThread=20);
ALIGN[,libID	:=	sample]
ALIGN[,sample	:=	NULL]
SPlist			=	VR$libID %>% sort %>% unique
SPlist2			=	ALIGN$libID %>% sort %>% unique;
tmp				=	setdiff(SPlist,SPlist2)
if(length(tmp)	>	0){cat(paste(tmp,collapse=",")," are missing from the ALIGN file\n");}
stopifnot(length(tmp)==0)
ALIGN			=	ALIGN[libID %chin% SPlist,]
ALIGN[superkingdom=="Enterobacteriaceae",]
ALIGN[superkingdom=="Enterobacteriaceae",superkingdom:="Bacteria"]
ALIGN[superkingdom=="Enterobacteriaceae",superkingdom:="Bacteria"]

align			=	fread(inputF22,sep="\t",head=T,nThread=20);
align[,libID	:=	sample]
align[,sample	:=	NULL]
SPlist			=	VR$libID %>% sort %>% unique
SPlist2			=	align$libID %>% sort %>% unique;
tmp				=	setdiff(SPlist,SPlist2)
if(length(tmp)	>	0){cat(paste(tmp,collapse=",")," are missing from the align file\n");}
stopifnot(length(tmp)==0)
align			=	align[libID %chin% SPlist,]
align[superkingdom=="Enterobacteriaceae",]
align[superkingdom=="Enterobacteriaceae",superkingdom:="Bacteria"]
align[superkingdom=="Enterobacteriaceae",superkingdom:="Bacteria"]

partA			=	ALIGN[!((libID %chin% VR[SampleType=="CSF",libID])&grepl("Mycobacterium|Ralstonia",species))];#remove braken's Mycobacterium and Ralstonia from CSF
partB			=	align[ ((libID %chin% VR[SampleType=="CSF",libID])&grepl("Mycobacterium|Ralstonia",species))];#extract kraken's Mycobacterium and Ralstonia from CSF
ALIGN			=	rbind(partA,partB);	# merge partA & B
ALIGN[grepl("Mycobacterium bovis",species)|grepl("Mycobacterium tuberculosis",species)|grepl("Mycobacterium africanum",species)|grepl("Mycobacterium mioroti",species),	species:="Mycobacterium tuberculosis"]
ALIGN[grepl("Ralstonia",species),		species:="Ralstonia sp."]


################################	formating species names
ALIGN[,II		:=	.I]
ALIGN[,RPM		:=	round(1000000/(100*reads/abundance)*reads,0)]
my_fuc			=	function(x){y=unlist(strsplit(x,split=" "));paste(y[1],y[2],sep=" ")} #
ALIGN[,species_nano	:=	ifelse(superkingdom=="Viruses",species,my_fuc(species)),by=II];
ALIGN[,species	:=	NULL]
ALIGN[grepl("\\[|\\]",species_nano),species_nano:=gsub("\\[|\\]","",species_nano),]
ALIGN[grepl("\\[|\\]",genus),genus:=gsub("\\[|\\]","",genus),]
tmp				=	copy(VR[,.SD[,c('libID','RunID','sampleID','SampleType','libType')]])
ALIGN			=	tmp[ALIGN,on='libID',]
ALIGN			=	ALIGN[(!grepl("^[0-9]+",species_nano))&species_nano!="Homo_sapiens"&species_nano != "N/A_"&superkingdom!="N/A"&!grepl("uncultured",species_nano)&!(superkingdom=="Viruses"&grepl("phage",species_nano)),];

################################	one sample one output, one batch one background
#merge replicates
ALIGN1			=	ALIGN[,.(taxid=head(taxid,1),genus=head(genus,1),superkingdom=head(superkingdom,1),reads=sum(reads),RPM=sum(RPM)),by=c('RunID','sampleID','SampleType','libType','species_nano')]
ALIGN1[,II		:=	.I]
ALIGN1[,mk		:=	paste(RunID,sampleID,libType,sep="_"),by=II]
ALIGN1[,mk2		:=	paste(RunID,libType,species_nano,sep="_"),by=II];
#account for IC
ALIGN2			=	ALIGN1[!((species_nano=="Escherichia virus Lambda"&libType=="RNA")|(species_nano=="Escherichia virus MS2"&libType=="DNA"))]
DNAIC			=	ALIGN2[species_nano=="Escherichia virus Lambda",.(reads_IC=reads,RPM_IC=RPM),by=mk]
RNAIC			=	ALIGN2[species_nano=="Escherichia virus MS2",.(reads_IC=reads,RPM_IC=RPM),by=mk]
mx_IC			=	rbind(DNAIC,RNAIC)
ALIGN3			=	mx_IC[ALIGN2,on='mk']
#account for background
Signal			=	ALIGN3[!grepl("water",sampleID),]
Backgd			=	ALIGN3[grepl("water",sampleID),.(reads_back=reads,reads_BKIC=reads_IC,RPM_back=RPM,RPM_BKIC=RPM_IC,mk2=mk2)];
ALIGN4			=	Backgd[Signal,on='mk2']
ALIGN4[is.na(reads_IC),		reads_IC:=0,]
ALIGN4[is.na(reads_BKIC),	reads_BKIC:=0,]
ALIGN4[is.na(reads_back),	reads_back:=0,]
ALIGN4[is.na(RPM_IC),		RPM_IC:=0,]
ALIGN4[is.na(RPM_BKIC),	RPM_BKIC:=0,]
ALIGN4[is.na(RPM_back),	RPM_back:=0,]
#remove IC reads from matrix; 
ALIGN5			=	ALIGN4[species_nano!="Escherichia virus Lambda"&species_nano!="Escherichia virus MS2"]
#ALIGN5 is without IC reads, without background reads in the matrix rows
########	option1 merge RNA lib and DNA lib together
RNApatholist	=	PATHO[libType=="RNA",patho] %>% sort %>% unique;
MX1				=	copy(ALIGN5[(libType=="DNA"&(!species_nano %chin% RNApatholist))|(libType=="RNA"&species_nano %chin% RNApatholist),])
MX_option1		=	MX1[,.(	reads=sum(reads),reads_back=sum(reads_back),reads_IC=sum(reads_IC),reads_BKIC=sum(reads_BKIC),
							RPM=sum(RPM),RPM_back=sum(RPM_back),RPM_IC=sum(RPM_IC),RPM_BKIC=sum(RPM_BKIC),
							mk=paste(RunID,sampleID,sep="_"),libType="DNARNA"
							),by=c('RunID','sampleID','SampleType','taxid','superkingdom','genus','species_nano')]
################################	summary error source
sub_anno_error	=	function(tmp){
tmp[,rmvABD		:=	"ABD"];
tmp[MicroSum>100&((rlaPct>1e-4&SampleType=="CSF")|(rlaPct>1e-4&SampleType=="respiratory")|(rlaPct>1e-3&SampleType=="urinary")),rmvABD:="GD",];
tmp[,rmvBRD		:=	"GD"];
tmp[(brd_leak2/RPM>100),rmvBRD:="BRD"];
tmp[,rmvMIS		:=	"GD"];
tmp[(mis_algn2/RPM>100),rmvMIS:="MIS"];
tmp[,fold		:=	(RPM/RPM_back)/(RPM_IC/RPM_BKIC),];
tmp[,foldIC		:=	RPM_IC/RPM,]
tmp[,foldBK		:=	RPM_back/RPM,];
tmp[,rmvFLD		:=	"FLD"];
tmp[((is.na(fold)|(fold>=2))&(foldBK<0.2)&(foldIC<10)&(SampleType!="CSF"))|((is.na(fold)|(fold>=2))&(foldBK<1.0)&((foldIC<100&species_nano=="Mycobacterium tuberculosis")|(foldIC<10&species_nano!="Mycobacterium tuberculosis"))&(SampleType=="CSF")),rmvFLD:="GD",]
tmp[,flg1		:=	paste(rmvABD,rmvBRD,rmvMIS,rmvFLD,sep=";"),by=mk2]
tmp[,flg2		:=	ifelse(grepl("MIS",flg1),"MIS",
					ifelse(grepl("BRD",flg1),"BRD",
					ifelse(grepl("FLD",flg1),"FLD",
					ifelse(grepl("ABD",flg1),"ABD","GD")))),]
tmp[,flg3		:=	ifelse(flg2=="GD"&grepl("TP",C_PcmpNANO),"good",
					ifelse(flg2=="GD"&grepl("FP",C_PcmpNANO),"should test",
					ifelse(grepl("FN",C_PcmpNANO),"should test",flg2))),]
#tmp[,c('rmvABD','rmvBRD','rmvMIS','rmvFLD')	:=	NULL]
tmp				=	tmp[,.SD[,c('RunID','sampleID','SampleType','Culture_results','PCRpos','PCRneg','C_PcmpNANO','flg1','flg2','flg3','species_nano','fold','foldIC','foldBK',
							'reads','reads_back','reads_IC','reads_BKIC','RPM','RPM_back','RPM_IC','RPM_BKIC','libType','BCID','MicroSum','RPMSum','rlaPct','BM_rank','brd_leak1','mis_algn1','brd_leak2','mis_algn2')]];
#tmp				=	tmp[!sampleID %chin% c('477','478','479','480','481','482','483','484','485','486'),]
tmp
}
################################	lowest cutoff, all pathogen would be reported 
BM1				=	sub_get_NanoID(MX_option1,VR_final1)
#IDL1			=	sub_get_NanoID_cutoff1(BM1,PATHO)
#BM1_anno		=	sub_comparison(BM1,CUL_out,PCR_out,IDL1);
#SM1_anno		=	sub_get_SMPout(BM1_anno)
#BM1_anno2		=	VR_final1[BM1_anno,on='mk']
#SM1_anno2		=	VR_final1[SM1_anno,on='mk']
#tmp				=	SM1_anno[,.(mk=paste(SampleType,C_PCMPNANO,sep=";"))]
#setorder(tmp,mk)
#SMP_table		=   tmp[,.N,by=mk]
#tmp				=	BM1_anno$SampleType %>% unique;
#compare_CULPCR	=	sub_statistic_table2(SMP_table,SampleType=tmp)
#compare_CULPCR;
#OUT1			=	list(BigMatrix=BM1_anno2,SmallMatrix=SM1_anno2,Comparison=compare_CULPCR)
#my_write(OUT1,file.path(output1,"K+B_NGS_SPE_SMP_cutoff1.xlsx"));
#tmp				=	SM1_anno2[grepl("FP|FN|TP",C_PCMPNANO),]
#setorder(tmp,SampleType,C_PCMPNANO,MicroSum)
#fwrite(tmp,	file=	file.path(output1,"K+B_FPFNTP_SM_cutoff1.xls"),sep="\t",col.name=T,row.name=F,quote=F)
#tmp				=	BM1_anno2[grepl("FP|FN|TP",C_PcmpNANO),]
#setorder(tmp,SampleType,species_nano,C_PcmpNANO,MicroSum)
#tmp				=	sub_anno_error(tmp);
#fwrite(tmp,	file=	file.path(output1,"K+B_FPFNTP_BM_cutoff1.xls"),sep="\t",col.name=T,row.name=F,quote=F)
################################	cutoff with brd, mis, abd, fold considered
BM2				=	copy(BM1)
IDL2			=	sub_get_NanoID_cutoff3(BM2,PATHO)
BM2_anno		=	sub_comparison(BM2,CUL_out,PCR_out,IDL2);
SM2_anno		=	sub_get_SMPout(BM2_anno)
BM2_anno2		=	VR_final1[BM2_anno,on='mk']
SM2_anno2		=	VR_final1[SM2_anno,on='mk']
tmp				=	SM2_anno[,.(mk=paste(SampleType,C_PCMPNANO,sep=";"))]
setorder(tmp,mk)
SMP_table		=   tmp[,.N,by=mk]
tmp				=	BM2_anno$SampleType %>% unique;
compare_CULPCR	=	sub_statistic_table2(SMP_table,SampleType=tmp)
compare_CULPCR;
OUT2			=	list(BigMatrix=BM2_anno2,SmallMatrix=SM2_anno2,Comparison=compare_CULPCR)
#my_write(OUT2,file.path(output1,"K+B_NGS_SPE_SMP_cutoff3.xlsx"));
my_write(OUT2, output1);
tmp				=	SM2_anno2[grepl("FP|FN|TP",C_PCMPNANO),]
setorder(tmp,SampleType,C_PCMPNANO,MicroSum)
#fwrite(tmp,	file=	file.path(output1,"K+B_FPFNTP_SM_cutoff3.xls"),sep="\t",col.name=T,row.name=F,quote=F)
fwrite(tmp,	file= output2, sep="\t",col.name=T,row.name=F,quote=F)
#tmp				=	BM2_anno2[grepl("FP|FN|TP",C_PcmpNANO),]
tmp				=	copy(BM2_anno2)
setorder(tmp,SampleType,species_nano,C_PcmpNANO,MicroSum)
tmp				=	sub_anno_error(tmp);
#fwrite(tmp,	file=	file.path(output1,"K+B_FPFNTP_BM_cutoff3.xls"),sep="\t",col.name=T,row.name=F,quote=F)
fwrite(tmp,	file=	output3, sep="\t",col.name=T,row.name=F,quote=F)

################################	remove wrong batch results
#BM3				=	copy(BM1[!sampleID %chin% c('477','478','479','480','481','482','483','484','485','486')])
#VR_final2		=	VR_final1[!sampleID %chin% c('477','478','479','480','481','482','483','484','485','486')]
#mks				=	VR_final2$mk %>% sort %>% unique
#CUL_out2		=	lapply(mks,sub_format_VR_cul,VR=VR_final2) %>% rbindlist
#PCR_out2		=	lapply(mks,sub_format_VR_pcr,VR=VR_final2) %>% rbindlist
#stopifnot(nrow(PCR_out2[pcrans=="wrong",])==0)
#
#IDL3			=	sub_get_NanoID_cutoff3(BM3,PATHO)
#BM3_anno		=	sub_comparison(BM3,CUL_out2,PCR_out2,IDL3);
#SM3_anno		=	sub_get_SMPout(BM3_anno)
#BM3_anno2		=	VR_final2[BM3_anno,on='mk']
#SM3_anno2		=	VR_final2[SM3_anno,on='mk']
#tmp				=	SM3_anno[,.(mk=paste(SampleType,C_PCMPNANO,sep=";"))]
#setorder(tmp,mk)
#SMP_table		=   tmp[,.N,by=mk]
#tmp				=	BM3_anno$SampleType %>% unique;
#compare_CULPCR	=	sub_statistic_table2(SMP_table,SampleType=tmp)
#compare_CULPCR;
#OUT3			=	list(BigMatrix=BM3_anno2,SmallMatrix=SM3_anno2,Comparison=compare_CULPCR)
##my_write(OUT3,file.path(output1,"K+B_NGS_SPE_SMP_cutoff3_goodbatch.xlsx"));
#my_write(OUT3, output4);
#tmp				=	SM3_anno2[grepl("FP|FN|TP",C_PCMPNANO),]
#setorder(tmp,SampleType,C_PCMPNANO,MicroSum)
##fwrite(tmp,	file=	file.path(output1,"K+B_FPFNTP_SM_cutoff3_goodbatch.xls"),sep="\t",col.name=T,row.name=F,quote=F)
#fwrite(tmp,	file= output5, sep="\t",col.name=T,row.name=F,quote=F)
#tmp				=	BM3_anno2[grepl("FP|FN|TP",C_PcmpNANO),]
#setorder(tmp,SampleType,species_nano,C_PcmpNANO,MicroSum)
#tmp				=	sub_anno_error(tmp);
##fwrite(tmp,	file=	file.path(output1,"K+B_FPFNTP_BM_cutoff3_goodbatch.xls"),sep="\t",col.name=T,row.name=F,quote=F)
#fwrite(tmp,	file= output6, sep="\t",col.name=T,row.name=F,quote=F)
#
