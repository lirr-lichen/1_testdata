import pandas as pd
import re
import os, sys
import argparse

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for nerve_ngs result arrange and output.')
#    parser.add_argument('--QC', help='An input directory contains QC log files(fastp, seqkit, cutadapt).', type=str, required = True)
    parser.add_argument('--blast', help='An input directory contains blast results.', type=str)
    parser.add_argument('--kraken', help='An input directory contains kraken results.', type=str, required = True)
    parser.add_argument('--output', help='An output file to save final results, default as xlsx format.', type=str, required = True)
#    parser.add_argument('--chimera', help="A directory contained all the chimera results.", type=str, required = True)
#    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args

def kraken2_result(args1):
    '''This is a function to extract the number of DNA_IC reads, RNA_IC reads, remaining human spaciens' reads after blasting.'''
#    list1 = ['Escherichia virus Lambda', 'Escherichia virus MS2', 'Human gammaherpesvirus 4', 'Enterovirus A', 'Listeria monocytogenes', 'Klebsiella pneumoniae', 'Cryptococcus neoformans']
    data = pd.read_csv(args1, sep = '\t')
    data.rename(columns = {"name": 'species', "new_est_reads": 'reads', "abun_total_reads(%)": 'abundance'}, inplace = True)
#    result = pd.DataFrame({'species': list1}, index = range(len(list1)))
#    output = pd.merge(data[data['species'].isin(list1)],result, how = 'outer')
#    output.fillna(0.0, inplace = True)
#    pollution = data[data['species'].str.contains('Pseudomonas|Burkholderia')]
#    output = output.append([{'species': 'Pseudomonas_Burkholderia', 'reads': pollution['reads'].sum(),'abundance': pollution['abundance'].sum()}])
    output = data[["species", "reads", "abundance"]]
    output.set_index('species', inplace = True)
    output.fillna(0.0, inplace = True)
#    del output['species']
    del output.index.name
    reads = pd.DataFrame(output['reads'].to_dict(), index=[0])
    abundance = output['abundance'].to_dict()
    abundance2 = {}
    for i in abundance.keys():
        abundance2[str(i) + "_abundance"] = abundance[i]
    reads2 = pd.DataFrame(abundance2, index = [0])
#    reads3 = pd.DataFrame({'blastN': data['reads'].sum()}, index = [0])
    final = pd.concat([reads, reads2], axis = 1)
#    final = pd.concat([final1, reads3], axis = 1)
    #    final.fillna(0.0)
    return (final)
def blast_result(args1):
    '''This is a function to extract the number of DNA_IC reads, RNA_IC reads, remaining human spaciens' reads after blasting.'''
#    list1 = ['Escherichia virus Lambda', 'Escherichia virus MS2', 'Human gammaherpesvirus 4', 'Enterovirus A', 'Listeria monocytogenes', 'Klebsiella pneumoniae', 'Cryptococcus neoformans']
    data = pd.read_csv(args1, sep = '\t', header = None)
    data.rename(columns = {0: 'species', 1: 'reads', 2: 'abundance'}, inplace = True)
#    result = pd.DataFrame({'species': list1}, index = range(len(list1)))
#    output = pd.merge(data[data['species'].isin(list1)],result, how = 'outer')
#    output.fillna(0.0, inplace = True)
#    pollution = data[data['species'].str.contains('Pseudomonas|Burkholderia')]
#    output = output.append([{'species': 'Pseudomonas_Burkholderia', 'reads': pollution['reads'].sum(),'abundance': pollution['abundance'].sum()}])
    output = data[["species", "reads", "abundance"]]
    output.set_index('species', inplace = True)
    output.fillna(0.0, inplace = True)
#    del output['species']
    del output.index.name
    reads = pd.DataFrame(output['reads'].to_dict(), index=[0])
    abundance = output['abundance'].to_dict()
    abundance2 = {}
    for i in abundance.keys():
        abundance2[str(i) + "_abundance"] = abundance[i]
    reads2 = pd.DataFrame(abundance2, index = [0])
 #   reads3 = pd.DataFrame({'blastN': data['reads'].sum()}, index = [0])
    final = pd.concat([reads, reads2], axis = 1)
 #   final = pd.concat([final1, reads3], axis = 1)
#    final.fillna(0.0)
    return (final)

def main():
    args = parse_input()
    kraken2 = pd.DataFrame()
    for dirpath, dirname, files in os.walk(args.kraken):
        for fi in files:
            if fi.endswith("final.bracken"):
                name = fi.split(".")[0]
                df = kraken2_result(os.path.join(dirpath, fi))
                df["sample"] = name
                kraken2 = pd.concat([kraken2, df], sort = True)
    xlsx = pd.ExcelWriter(args.output)
    tags = kraken2.columns.tolist()
    tags.remove("sample")
    Tag = ["sample"]
    for i in sorted(tags):
        Tag.append(i)
    kraken2 = kraken2[Tag]
    kraken2.to_excel(xlsx, sheet_name="kraken2", index=False)
    if args.blast:
        blast = pd.DataFrame()
        for dirpath, dirname, files in os.walk(args.blast):
            for fi in files:
                if fi.endswith("abundance.tsv"):
                    name = fi.split(".")[0]
                    df = blast_result(os.path.join(dirpath, fi))
                    df["sample"] = name
                    blast = pd.concat([blast, df], sort = True)
        tags = blast.columns.tolist()
        tags.remove("sample")
        Tag = ["sample"]
        for i in sorted(tags):
            Tag.append(i)
        blast = blast[Tag]
        blast.to_excel(xlsx, sheet_name = "blast", index = False)
    xlsx.close()
    print ("Finished the results arrange.")

if __name__ == "__main__":
    main()
