import os, sys
import numpy as np
import pandas as pd
import re
import  argparse
import copy

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2 result arrange based on species level, and add the genus, superkingdom information.')
    parser.add_argument('--IC', help='An IC kraken result file.', type=str, required=True)
    parser.add_argument('--microbial', help='A microbial kraken result file.', type = str, required=True)
    parser.add_argument("--taxDB", help = "A taxDB file contains the species_genus_superkingdom relationship.", type = str, required=True)
    parser.add_argument('--output', help='An output file to save the results.', type=str, required=True)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args
def data_extract(args1):
    result = {"species":[], "taxid": [], "reads": []}
    with open(args1) as f:
        for line in f:
            line  = line.strip()
            ls = line.split("\t")
            if ls[3].strip() == "S":
                result["species"].append(ls[-1].strip())
                result["reads"].append(int(ls[1].strip()))
                result["taxid"].append(int(ls[-2].strip()))
#                result["abundance"].append(ls[0].strip())
    return (result)
def main():
    args = parse_input()
    sample = os.path.basename(args.IC).split(".")[0]
    IC_result = pd.DataFrame(data_extract(args.IC))
    microbial_result = pd.DataFrame(data_extract(args.microbial))
    result = pd.concat([IC_result, microbial_result], sort = True)
    result["abundance"] = 100* result["reads"]/result["reads"].sum()
#    output = copy.deepcopy(result)
    refer = pd.read_csv(args.taxDB, sep = "\t")
    output = pd.merge(result, refer[[ "genus", "superkingdom", "taxid"]], on = "taxid", how = "inner")
    output = copy.deepcopy(output)
    output["sample"] = sample
    output["abundance"] = output["abundance"].apply(lambda x: round(x, 5))
    output.sort_values(by = "abundance", ascending=False, inplace=True)
    output = output[["sample", "species", "taxid", "genus", "superkingdom", "reads", "abundance"]]
    output.to_csv(args.output, sep = "\t", index=False)
    return ("Finished the kraken2 original result arrange.")

if __name__ == "__main__":
    main()