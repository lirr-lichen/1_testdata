import os, sys
import shlex
import subprocess
import argparse

# python3 /gpfsdata/users/liangxz/software/Bracken/src/est_abundance.py \
#         -i $outdir/$sample/${sample}_ic.report \
#         -k $ic_db/database150mers.kmer_distrib \
#         -o $outdir/$sample/${sample}_ic.bracken -l S -t 1
#
def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for nerve_ngs IC bracken analysis.')
    parser.add_argument('--input', help='An input kraken2 report file.', type=str, required = True)
    parser.add_argument("--microbial", help = "The microbial bracken result.", type = str, required= True)
    parser.add_argument('--kmer', help='A kmer file of bracken.', type=str, required = True)
    parser.add_argument('--software', help=' The bracken script.', type=str, required = True)
    parser.add_argument('--level', help='The analysis level.',choices= ['S','D','P','C','O','F','G'], type=str, default= 'S')
    parser.add_argument("--IC", help = "The IC bracken result.", type = str)
    parser.add_argument('--output', help='An output file to save the result.', type=str, required = True)
    parser.add_argument('--threads', help="Threads used in the analysis.", type=str, required = True)
    parser.add_argument('--merge', help = 'A bracken merge script.', type = str, required = True)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args
def main():
    args = parse_input()
    line = subprocess.Popen(["grep", "Escherichia", args.input], stdout=subprocess.PIPE)
    if len(line.stdout.readline()) > 0:
        work = subprocess.Popen(["python3", args.software, "-i", args.input, "-k", args.kmer, "-l", args.level, "-t", args.threads, "-o", args.IC], stdout = subprocess.PIPE)
        for line in work.stdout.readlines():
            print (line)
        merge = subprocess.Popen(["perl", args.merge, args.IC, args.microbial, args.output], stdout = subprocess.PIPE)
        for line in merge.stdout.readlines():
            print (line)
    else:
        w = open(args.IC, 'w')
        w.write("Nothing\n")
        w.close()
        subprocess.Popen(["cp", args.microbial, args.output], stdout= None)
        print ("Finished the microbial bracken result cp to the final bracken result, as the IC.report contained nothing.")
    print ("Finished the bracken merge work.")
if __name__ == "__main__":
    main()