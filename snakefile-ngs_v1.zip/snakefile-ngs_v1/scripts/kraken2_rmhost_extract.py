import gzip
import argparse
import os, sys
import subprocess


def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for the kraken2 rmhost reads extract, \
    extract those reads filtered by other steps.')
#    parser.add_argument('--QC', help='An input directory contains QC benchmark files(fastp, seqkit, cutadapt).', type=str, required = True)
    parser.add_argument('--filter', help='An input fastq file, reads in it will be exclude.', type=str, required = True)
#    parser.add_argument('--blast', help='An input directory contains blast results.', type=str)
    parser.add_argument('--origin', help='An input fastq file, reads in it will be filtered.', type=str, required = True)
    parser.add_argument('--output', help='An output fastq file to save the extracted reads.', type=str, required = True)
#    parser.add_argument('--chimera', help="A directory contained all the chimera results.", type=str, required = True)
#    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return (args)

def main():
    args = parse_input()
    list_origin = []
    lines = subprocess.Popen("grep -e '^@' {} | cut -d ' ' -f 1".format(args.origin), shell = True, stdout = subprocess.PIPE)
    for line in lines.stdout.readlines():
        list_origin.append(line.strip().decode())
    list_filter = []
    lines = subprocess.Popen("grep -e '^@' {} | cut -d ' ' -f 1".format(args.filter), shell = True, stdout = subprocess.PIPE)
    for line in lines.stdout.readlines():
        list_filter.append(line.strip().decode())
    list_out = list(set(list_origin) - set(list_filter))
    w = open(args.output, 'w')
    f = open(args.origin, 'r')
    list_file = f.read().split("@")
    for i in list_file[1:]:
        ls = i.split("\n")
        tag = "@" + ls[0].split()[0]
        if tag in list_out:
            w.write("@" + i)
    w.close()
    f.close()
if __name__ == "__main__":
    main()


#with gzip.open(args.fastq, 'rb') as fastq:
#    for line in fastq:
#        if line.decode().startswith('@'):
#            fastqid = line.decode().strip().split()[0][1:]
#            fastqdict[fastqid] = ''
#        else:
#            fastqdict[fastqid] += line.decode()

#outfile = gzip.open(args.outfile, 'wb')

#with gzip.open(args.idlist, 'rb') as idfile:
#    for line in idfile:
#        readsid = line.decode().strip()
#        for key in fastqdict.keys():
#            if readsid == key:
#                res = '@' + key + '\n' + fastqdict[key]
#                outfile.write(res.encode())

#outfile.close()
