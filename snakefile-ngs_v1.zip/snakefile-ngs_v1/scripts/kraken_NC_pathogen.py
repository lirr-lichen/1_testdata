import os, sys
import numpy as np
import pandas as pd
import re
import copy
import  argparse


def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2_bracken result NC relative abundance statistic.')
    parser.add_argument('--kraken', help='A directory of bracken results.', type=str, required=True)
    parser.add_argument("--pathogen", help = "A file contains all the pathogenic species.", type = str, default="/gpfsdata/users/zhangyan/NGS_database_20200510/pathogen_list/pathogen.tsv")
    parser.add_argument("--genus", help = "A file contains all the pathogenic genus level information.", type = str, default="/gpfsdata/users/zhangyan/NGS_database_20200510/pathogen_list/pathogen_genus.tsv")
    parser.add_argument("--sampleinformation", help = "A sample information file contains all the samples needed information.", type=str, required=True)
    parser.add_argument('--origin', help='An output to save original NC results.', type=str, required=True)
    parser.add_argument("--final", help = "An output to save the final results after filter.", type=str, required= True)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
    args = parser.parse_args()
    return args
def sample_infor(args1):
    infor = pd.read_excel(args1)
    DNA_samples = infor[(infor["样本类型"].notnull()) & (infor["建库类型"] == "DNA文库")]["样本文库编号"].tolist()
    RNA_samples = infor[(infor["样本类型"].notnull()) & (infor["建库类型"] == "RNA文库")]["样本文库编号"].tolist()
    DNA_IC = infor[(infor["NC类型"] == "IC") & (infor["建库类型"] == "DNA文库")]["样本文库编号"].tolist()
    RNA_IC = infor[(infor["NC类型"] == "IC") & (infor["建库类型"] == "RNA文库")]["样本文库编号"].tolist()
    NC_samples = infor[(infor["NC类型"] == "NC") & (infor["建库类型"] == "NC")]["样本文库编号"].tolist()
    DNA_samples.extend(RNA_samples)
    DNA_IC.extend(RNA_IC)
    return (DNA_samples, DNA_IC, NC_samples)

def NC_average(*args):
    """A function for DNA_IC_NC, RNA_IC_NC, NC samples abundance mean compute."""
    output = {}
    for fi in args:
        for j in fi:
            f = open(j, 'r')
            f.readline()
            for line in f:
                line = line.strip()
                ls = line.split("\t")
                if ls[0] not in output:
                    output[ls[0]] = []
                output[ls[0]].append(float(ls[-1]))
            f.close()
    result = {}
    for j in output.keys():
        result[j] = np.mean(output[j])
    df = pd.DataFrame(result, index = [0]).T
    df.reset_index(inplace = True)
    df.rename(columns= {"index": "species", 0: "abundance"}, inplace = True)
    return(df)
def NC_normalization(kraken, NC_IC = None, NC = None):
    data = pd.read_csv(kraken, sep = "\t", usecols=[0, 1, 5, 6])
    if "fraction_total_reads" in data.columns.tolist():
        data["fraction_total_reads"] = data["fraction_total_reads"] * 100
    data.rename(columns={"name": "species", "taxonomy_id": "taxid", "new_est_reads": "reads", "abun_total_reads(%)": "abundance"}, inplace=True)
    data.rename(columns={"fraction_total_reads": "abundance"}, inplace=True)  ## a few special samples
    result = ""
    if NC_IC and not NC:
        NC_IC_data = NC_average(NC_IC)
        result = pd.merge(data, NC_IC_data, on="species", how="left")
        result.rename(columns={"abundance_x": "abundance", "abundance_y": "abundance_NC_IC"}, inplace=True)
        result["abundance_NC"] = None
        result["IC_ratio"] = result["abundance"] / result["abundance_NC_IC"]
        result["NC_ratio"] = None
        result.sort_values(by=["IC_ratio"], ascending=False, inplace=True)
    if NC and not NC_IC:
        NC_data = NC_average(NC)
        result = pd.merge(data, NC_data, on="species", how="left")
        result.rename(columns={"abundance_x": "abundance", "abundance_y": "abundance_NC"}, inplace=True)
        result["abundance_NC_IC"] = None
        result["IC_ratio"] = None
        result["NC_ratio"] = result["abundance"] / result["abundance_NC"]
        result.sort_values(by=["NC_ratio"], ascending=False, inplace=True)
    if NC_IC and NC:
        NC_IC_data = NC_average(NC_IC)
        NC = NC_average(NC)
        result1 = pd.merge(data, NC_IC_data, on = "species", how = "left")
        result = pd.merge(result1, NC, on = "species", how = "left")
        result.rename(columns= {"abundance_x": "abundance", "abundance_y" : "abundance_NC_IC", "abundance": "abundance_NC"}, inplace= True)
        result["IC_ratio"] = result["abundance"] / result["abundance_NC_IC"]
        result["NC_ratio"] = result["abundance"] / result["abundance_NC"]
        result.sort_values(by=["IC_ratio", "NC_ratio"], ascending=False, inplace=True)
    result = result[["species", "reads", "abundance", "abundance_NC_IC", "abundance_NC", "IC_ratio", "NC_ratio"]]
    return (result)
def NC_filter(samples_list, NC_IC_samples = None, NC_samples_list = None, kraken_path = "/gpfsdata/users/zhangyan/nerve_ngs/20200615_results/kraken_20200528", IC_ratio = 0.8, NC_ratio = 3):
    result = pd.DataFrame()
    if NC_IC_samples and len(NC_IC_samples) > 0:
        NC_IC_list = [os.path.join(kraken_path, i + ".final.bracken") for i in NC_IC_samples]
        for i in samples_list:
            data = NC_normalization(i, NC_IC= NC_IC_list, NC=NC_samples_list)
            data["sample"] = os.path.basename(i).split(".")[0]
            data = data[["sample", "species", "reads", "abundance", "abundance_NC_IC", "abundance_NC", "IC_ratio", "NC_ratio"]]
            result = pd.concat([result, data], sort=True)
    else:
        for i in samples_list:
            data = NC_normalization(i, NC=NC_samples_list)
            data["sample"] = os.path.basename(i).split(".")[0]
            data = data[["sample", "species", "reads", "abundance", "abundance_NC_IC", "abundance_NC", "IC_ratio", "NC_ratio"]]
            result = pd.concat([result, data], sort=True)
    result = result[["sample", "species", "reads", "abundance", "abundance_NC_IC" , "abundance_NC" ,"IC_ratio", "NC_ratio"]]
    filter = result[(result["IC_ratio"].isnull()) & (result["NC_ratio"].isnull())]
    filter1 = result[(result["IC_ratio"] > IC_ratio) & (result["NC_ratio"].isnull())]
    filter2 = result[(result["IC_ratio"].isnull()) & (result["NC_ratio"] > NC_ratio)]
    filter3 = result[(result["IC_ratio"] > IC_ratio) & (result["NC_ratio"] > NC_ratio)]
    filter = pd.concat([filter, filter1, filter2, filter3], sort=True)
    filter = filter[["sample", "species", "reads", "abundance"]]
    return (result, filter)
def pathogen_filter(filter, pathogen, pathogen_genus, samples_type):
    filter["genus"] = filter["species"].apply(lambda x: x.split(" ")[0])
    genus = copy.deepcopy(filter.groupby(by=["sample", "genus"])[["reads", "abundance"]].sum())
    genus.reset_index(inplace= True)
    del filter["genus"]
# part 1 add the pathogen filter part
#    pathogen.replace({"CSF": "other", "respiratory": "other"}, inplace = True)
    pathogen_genus = pathogen_genus["genus"].tolist()
    pathogen = pathogen["species"].tolist()
#    pathogen = pathogen[pathogen["type"].isin(["CSF", "respiratory"])]["species"].tolist()
#    filter["genus_abundance"] = filter["abundance"].groupby(filter["genus"]).sum()
#    genus = pd.merge(genus, samples_type, on = "sample", how = "left")
#    output2 =pd.merge(genus, pathogen_genus, on = ["type", "genus"], how = "inner")
    output2 = genus[genus["genus"].isin(pathogen_genus)]
#    filter = pd.merge(filter, samples_type, on = "sample", how = "left")
#    filter.replace({"CSF": "other", "respiratory": "other"}, inplace=True)
#    output1 = pd.merge(filter, pathogen, on = ["type", "species"], how = "inner")
    output1 = filter[filter["species"].isin(pathogen)]
# part 2, abundance filter, and some special species manipulate
    output1 = output1[output1["abundance"] > 0.1]
    output2 = output2[output2["abundance"] > 0.1]
#    output1.drop((output1["species"].isin(["Acinetobacter baumannii", "Escherichia coli", "Klebsiella pneumoniae"])) & (output1["abundance"] < 5.0))
    output3 = copy.deepcopy(output1[~output1["species"].isin(["Acinetobacter baumannii", "Escherichia coli", "Klebsiella pneumoniae", "Pseudomonas aeruginosa"])])
    output4 = copy.deepcopy(output1[output1["species"].isin(["Acinetobacter baumannii", "Escherichia coli", "Klebsiella pneumoniae", "Pseudomonas aeruginosa"])])
    output4 = output4[output4["abundance"] > 5]
    output1 = pd.concat([output3, output4], sort = True)
# part 3 find the max abundance species of each sample, drop the sample if it less than 30%
#    print (output1["abundance"].count())
#    print (output1)
    output1.reset_index(inplace = True)
    g1 = output1.groupby(["sample"])["abundance"].idxmax()
#    print (g1)
    df = output1.iloc[g1]
    df = copy.deepcopy(df)
    drop_list = df[df["abundance"] < 30]["sample"].tolist()
    output1 = copy.deepcopy(output1[~output1["sample"].isin(drop_list)])
# part 4 result format part
    output1 = copy.deepcopy(output1)
    output2 = copy.deepcopy(output2)
    output1["species_result"] = output1["species"]  + " " + output1["reads"].apply(lambda x: str(x)) + " " + "(" + output1["abundance"].apply(lambda x: str(round(x,2)) + "%") + ")"
    output2["genus_result"] = output2["genus"] + ".sp" + " " + output2["reads"].apply(lambda x: str(x)) + " " + "(" + output2["abundance"].apply(lambda x: str(round(x,2)) + "%") + ")"
    result = pd.merge(output1[["sample", "species_result"]], output2[["sample", "genus_result"]], on = "sample", how = "outer")
    result.drop_duplicates(subset=["species_result", "genus_result"], keep= "first", inplace=True)
    result.sort_values(by = "sample", inplace=True)
    return (result)

def main():
    args = parse_input()
    samples_information = sample_infor(args.sampleinformation)
    samples, NC_IC_samples, NC_samples = samples_information[0], samples_information[1], samples_information[2]
    samples_list = [os.path.join(args.kraken, i + ".final.bracken") for i in samples]
    NC_samples_list = [os.path.join(args.kraken, i + ".final.bracken") for i in NC_samples]
    pathogen = pd.read_csv(args.pathogen, sep = "\t")
#    pathogen = pathogen["species"].tolist()
    pathogen_genus = pd.read_csv(args.genus, sep = "\t")
#    pathogen_genus = pathogen_genus["genus"].tolist()
    samples_type = pd.read_excel(args.sampleinformation, usecols=[0,3])
    samples_type.rename(columns={"样本文库编号": "sample", "样本类型": "type"}, inplace=True)
    filter = NC_filter(samples_list=samples_list, NC_IC_samples= NC_IC_samples, NC_samples_list = NC_samples_list, kraken_path=args.kraken)
    filter[0].to_csv(args.origin, sep = "\t", index = False)
    result = pathogen_filter(filter[1], pathogen, pathogen_genus, samples_type)
    result.to_csv(args.final,sep = "\t", index = False)
if __name__ == "__main__":
    main()
