import  os, sys
import re
import pandas as pd
import  argparse

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for nerve_ngs QC statistic.')
    parser.add_argument('--QC', help='An input directory contains QC benchmark files(fastp, seqkit, cutadapt).', type=str, required = True)
    parser.add_argument('--rmhost', help='An input directory contains rmhost benchmark files(the final rmhost4 log mainly needed).', type=str, required = True)
    parser.add_argument('--blast', help='An input directory contains blast results.', type=str)
    parser.add_argument('--kraken', help='An input directory contains kraken benchmark results.', type=str, required = True)
    parser.add_argument('--output1', help='An output file to save final results, default as xlsx format.', type=str, required = True)
    parser.add_argument("--output2", help = "An output file to the blast statistic result.", type = str)
#    parser.add_argument('--chimera', help="A directory contained all the chimera results.", type=str, required = True)
#    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args

def main():
    args = parse_input()
    QC = {}
    QC["fastp"] = pd.DataFrame()
    QC["seqkit"] = pd.DataFrame()
    QC["cutadapt"] = pd.DataFrame()
#    fastp = pd.DataFrame()
#    seqkit = pd.DataFrame()
#    cutadapt = pd.DataFrame()
 #   rawdata = pd.DataFrame()
    for dirpath, dirname, files in os.walk(args.QC):
        for fi in files:
            if fi.endswith("fastp.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep='\t')
                data['sample'] = name
                QC["fastp"] = pd.concat([QC["fastp"], data], sort=True)
            if fi.endswith("rmdup.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep='\t')
                data['sample'] = name
                QC["seqkit"] = pd.concat([QC["seqkit"], data], sort=True)
            if fi.endswith("cutadapt.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep='\t')
                data['sample'] = name
                QC["cutadapt"] = pd.concat([QC["cutadapt"], data], sort=True)
#    rmhost = {"kraken2": pd.DataFrame(), "centrifuge": pd.DataFrame(), "bwa": pd.DataFrame(), "bowtie2": pd.DataFrame(), "seqkit_rmhost": pd.DataFrame()}
    rmhost = {"kraken2": pd.DataFrame(), "centrifuge": pd.DataFrame(), "bwa": pd.DataFrame(), "bowtie2": pd.DataFrame()}
    for dirpath, dirname, files in os.walk(args.rmhost):
        for fi in files:
            if fi.endswith("rmhost1.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = '\t')
                data['sample'] = name
                rmhost["kraken2"] = pd.concat([rmhost["kraken2"], data], sort = True)
            if fi.endswith("rmhost2.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = '\t')
                data['sample'] = name
                rmhost["centrifuge"] = pd.concat([rmhost["centrifuge"], data], sort = True)
            if fi.endswith("rmhost3.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = '\t')
                data['sample'] = name
                rmhost["bwa"] = pd.concat([rmhost["bwa"], data], sort = True)
            if fi.endswith("rmhost4.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = '\t')
                data['sample'] = name
                rmhost["bowtie2"] = pd.concat([rmhost["bowtie2"], data], sort = True)
#            if fi.endswith("seqkit.rmhost.benchmark.tsv"):
#                name = fi.split(".")[0]
#                data = pd.read_csv(os.path.join(dirpath, fi), sep = '\t')
#                data['sample'] = name
#                rmhost["seqkit_rmhost"] = pd.concat([rmhost["seqkit_rmhost"], data], sort = True)
    kraken2 = {"IC": pd.DataFrame(), "microbial" : pd.DataFrame(), "kmer": pd.DataFrame(), "flt": pd.DataFrame(), "microbial_bracken" : pd.DataFrame(), "final": pd.DataFrame()}
    for dirpath, dirname, files in os.walk(args.kraken):
        for fi in files:
            if fi.endswith("kraken.IC.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                data['sample'] = name
                kraken2["IC"] = pd.concat([kraken2["IC"], data], sort = True)
            if fi.endswith("kraken2.microbial.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                data["sample"] = name
                kraken2["microbial"] = pd.concat([kraken2["microbial"],data], sort = True)
            if fi.endswith("microbial.flt.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                data["sample"] = name
                kraken2["kmer"] = pd.concat([kraken2["kmer"], data], sort = True)
            if fi.endswith("flt.report.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                data["sample"] = name
                kraken2["flt"] = pd.concat([kraken2["flt"], data], sort = True)
            if fi.endswith("bracken.flt.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                data["sample"] = name
                kraken2["microbial_bracken"] = pd.concat([kraken2["microbial_bracken"], data], sort = True)
            if fi.endswith("merge.bracken.benchmark.tsv"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                data["sample"] = name
                kraken2["final"] = pd.concat([kraken2["final"], data], sort = True)

    columns = ["sample", "s", "h:m:s", "max_vms"]
    xlsx =  pd.ExcelWriter(args.output1)
    for i in QC.keys():
        result = QC[i][columns]
        result.sort_values(by = "sample", inplace = True)
        result.to_excel(xlsx, sheet_name = i, index = False)
    for i in rmhost.keys():
        result = rmhost[i][columns]
        result.sort_values(by="sample", inplace=True)
        result.to_excel(xlsx, sheet_name=i, index=False)
    for i in kraken2.keys():
        result = kraken2[i][columns]
        result.sort_values(by = "sample", inplace = True)
        result.to_excel(xlsx, sheet_name=i, index=False)
    xlsx.close()
    if args.blast and args.output2:
        blast = {"IC": pd.DataFrame(), "unmap": pd.DataFrame(), "NT": pd.DataFrame(), "abundance" : pd.DataFrame()}
        for dirpath, dirname, files in os.walk(args.blast):
            for fi in files:
                if fi.endswith("IC.blast.benchmark.tsv"):
                    name = fi.split(".")[0]
                    data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                    data["sample"] = name
                    blast["IC"] = pd.concat([blast["IC"], data], sort = True)
                if fi.endswith("unmap5.fasta.benchmark.tsv"):
                    name = fi.split(".")[0]
                    data = pd.read_csv(os.path.join(dirpath, fi), sep = '\t')
                    data["sample"] = name
                    blast["unmap"] = pd.concat([blast["unmap"], data], sort = True)
                if fi.endswith("NT.blast.benchmark.tsv"):
                    name = fi.split(".")[0]
                    data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                    data["sample"] = name
                    blast["NT"] = pd.concat([blast["NT"], data], sort = True)
                if fi.endswith("abundance.benchmark.tsv"):
                    name = fi.split(".")[0]
                    data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                    data["sample"] = name
                    blast["abundance"] = pd.concat([blast["abundance"], data], sort = True)
        xlsx = pd.ExcelWriter(args.output2)
        for i in blast.keys():
            result = blast[i][columns]
            result.sort_values(by="sample", inplace=True)
            result.to_excel(xlsx, sheet_name=i, index=False)
        xlsx.close()
    return ("Finished the benchmark statistic.")

if __name__ == "__main__":
    main()




