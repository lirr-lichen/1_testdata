
my($taxdb, $out) = @ARGV;


open IN, $taxdb || die;
open OUT, ">$out"|| die;

my (%taxdb, @taxdb);
while(<IN>){
    chomp;
    my($taxid, $taxid_parent, $rank) = (split(/\t/))[0,1,3];
    $taxdb{$taxid} = $taxid_parent;
    push @taxdb, $taxid;
}
close TMP;

    my %hash;
    for (my $i=0; $i<@taxdb; $i ++){
        
        while(){
            my $lineages = $taxdb[$i].",".$taxdb{$taxdb[$i]};
            my $j   = (split(/,/, $lineages))[-1];
            print OUT "$taxdb[$i]\t$lineages\n";
            
            if($taxdb{$j} eq "1"){
                break;
            }
        }
    }




    

close OUT;
