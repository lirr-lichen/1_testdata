#!/usr/bin/perl

my($kraken, $name, $outdir, $taxdb_lineages) = @ARGV;

# taxonomy lineages
# my $taxdb_lineages="/gpfsdata/users/liangxz/work/20.NGS/db/taxonomy/taxDB.topo";
my (%lineages, %lineages_map);
&get_lineages($taxdb_lineages, \%lineages, \%lineages_map);

# kraken optimization
open IN,  $kraken                            || die;
open OUT2,">$outdir/${name}_sameGenus.kraken"|| die;
open OUT3,">$outdir/${name}_diffGenus.kraken"|| die;

while(<IN>){
    chomp;
    my($classify, $read_id, $taxid, $read_len, $kmers) = (split(/\t/))[0,1,2,3,4];
    if($classify eq "U"){
        next;
    }else{
        my @kmer     = split(/\s/, $kmers);
        my @lineages = split(/\,/, $lineages{$taxid});
        pop @lineages;
        pop @lineages; # 至superkingdom level

        my @kmer_taxid;
        for (my $i = 0; $i < @kmer; $i ++ ){
            
            my ($kmer_taxid, $kmer_count) = (split(/\:/, $kmer[$i]))[0,1];
            if($kmer_taxid ne "0"){
                push @kmer_taxid, $kmer_taxid;
            }
        }
        my %uniq;
        @kmer_taxid  = grep {++ $uniq{$_} < 2} @kmer_taxid;
        #print $kmer_taxid[0]."\n";last;

        my %hash_a = map{$_=>1} @lineages;
        my %hash_b = map{$_=>1} @kmer_taxid;
        my %merge_all = map {$_ => 1} @lineages, @kmer_taxid;
        my @kmer_only = grep {!$hash_a{$_}} @kmer_taxid;

        #print $kmer_only[0]."\n";last;

        if(@kmer_only < 1){
            print OUT2 "$_\n";
        }else{
            
            my @kmer_taxid_2;
            for (my $j = 0; $j < @kmer_only; $j ++ ){
                my $genus_map;
                my @taxonomy_map = split(/\,/, $lineages_map{$kmer_only[$j]});
                my @taxonomy     = split(/\,/, $lineages{$kmer_only[$j]});
                for (my $jj=0; $jj < @taxonomy_map; $jj ++){
                    if($taxonomy_map[$jj] eq "genus"){
                        $genus_map = $taxonomy[$jj];
                        push @kmer_taxid_2, $genus_map;
                    }
                }
            }
            @kmer_taxid_2  = grep {++ $uniq{$_} < 2} @kmer_taxid_2;

            if (@kmer_taxid_2 > 0){
                my @kmer_only_2 = grep {!$hash_a{$_}} @kmer_taxid_2;
                
                if(@kmer_only_2 < 1){
                    print OUT2 "$_\n";
                }else{
                    print OUT3 "$_\n";
                }

            }else{
                print OUT3 "$_\n";
            }
            
        }
    }
}
close IN;
close OUT1;
close OUT2;
close OUT3;

#######
sub get_lineages{

    my($file, $hash1, $hash2) = @_;

    open TMP, $file || die;

    while(<TMP>){
        chomp;
        my($taxid, $lineages, $lineages_map) = (split(/\t/))[0,1,4];
        $$hash1{$taxid} = $lineages;
        $$hash2{$taxid} = $lineages_map;
    }
    close TMP;
}
