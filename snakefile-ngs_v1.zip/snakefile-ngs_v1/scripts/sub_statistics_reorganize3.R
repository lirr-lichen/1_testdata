
################################ For samples in the next stage, the culture results no more had.
sub_format_VR_cul=	function(mk_i,VR){
	tmp			=	VR[mk_i,];
	spes		=	unlist(strsplit(tmp$Culture_results,split=";"));
	if(length(spes)==0){spes=NA;}
	tmp1		=	setDT(list(species_cul=spes,mk=rep(mk_i,length(spes))));
	tmp2		=	tmp[tmp1,on='mk'];
	tmp2[,culans:=	ifelse(all(is.na(spes)),'neg','pos')]
	tmp2[,mk2	:=	paste(mk,species_cul,sep=";")]
	tmp2		=	tmp2[,.SD[,c('mk2','species_cul','culans')]]
}
sub_format_VR_pcr=	function(mk_i,VR){
	tmp			=	VR[mk_i,];
	spes_pos	=	unlist(strsplit(tmp$PCRpos,split=";"));
	spes_neg	=	unlist(strsplit(tmp$PCRneg,split=";"));
	spes_share	=	intersect(spes_pos,spes_neg)
	spes_all	=	union(union(spes_pos,spes_neg),NA)
	tmp1		=	setDT(list(species_pcr=spes_all,mk=rep(mk_i,length(spes_all))));
	tmp2		=	tmp[,.SD[,-c('Culture_results','PCRpos','PCRneg')]][tmp1,on='mk'];
	tmp2[,pcrans:=	ifelse(species_pcr %chin% spes_share,'wrong',
					ifelse(species_pcr %chin% spes_neg,'neg',
					ifelse(species_pcr %chin% spes_pos,'pos',
					ifelse(is.na(species_pcr),'wait','wrong'))))]
	tmp2[,mk2	:=	paste(mk,species_pcr,sep=";")]
	tmp2		=	tmp2[,.SD[,c('mk2','species_pcr','pcrans')]]
}
sub_get_NanoID	=	function(MX_option1,VR3){
	SampleMeta		=	copy(VR3[,.SD[,c('mk','SampleType')]])
	BM				=	copy(MX_option1);
	BM[,BCID		:=	mk,]
	BM[,MicroSum	:=	sum(reads),by=mk]
	BM[,RPMSum		:=	sum(RPM),by=mk]
	BM[,rlaPct		:=	reads/MicroSum,];
	BM[,BM_rank		:=	frank(-reads,ties.method="min"),by=mk];
	BcdLeakMisaln	=	get_BcdLeak_Misaln(BM);
	BM				=	cbind(BM,BcdLeakMisaln);
	BM[,mk2			:=	paste(mk,species_nano,sep=";")];
	setkey(BM,mk2)
	BM[,SampleType	:=	NULL]
	#complete the matrix, there might be samples with Nano detected zero reads.
	addlist			=	setdiff(SampleMeta$mk,BM$mk);
	if(length(addlist)>0){
	addlist2		=	paste(addlist,NA,sep=";")
	alllist			=	c(BM$mk2[1],addlist2)
	tmp				=	BM[alllist,];
	tmp				=	tmp[mk2 != BM$mk2[1],]
	tmp$mk			=	addlist
	BM2				=	rbind(BM,tmp);
	}else{
	BM2				=	BM;
	}
	SampleMeta		=	copy(VR3[,.SD[,c('mk','SampleType','RunID','sampleID')]])
	BM2[,c('RunID','sampleID'):=	NULL]
	BM3				=	SampleMeta[BM2,on='mk'];
	BM3
}
sub_get_NanoID_cutoff1=	function(BM1,patho1){
	BM				=	copy(BM1)
	BM[,mk3			:=	paste(SampleType,species_nano,sep="_"),];
	patho			=	copy(patho1);
	patho[,mk3		:=	paste(SampleType,patho,sep="_"),]
	patholist		=	patho[,mk3]
	SM1				=	BM[mk3 %chin% patholist];
	NanoIDlist		=	SM1[,mk2]
}
sub_get_NanoID_cutoff2=	function(BM1,patho1){
	BM				=	copy(BM1)
	BM[,mk3			:=	paste(SampleType,species_nano,sep="_"),];
	patho			=	copy(patho1);
	patho[,mk3		:=	paste(SampleType,patho,sep="_"),]
	patholist		=	patho[,mk3]
	SM1				=	BM[mk3 %chin% patholist];
	SM1				=	SM1[(rlaPct>1e-4&SampleType=="CSF")|(rlaPct>1e-4&SampleType=="respiratory")|(rlaPct>1e-3&SampleType=="urinary")];
	SM1				=	SM1[!((brd_leak1/reads>100)|(brd_leak2/RPM>100)),]
	SM1				=	SM1[!((mis_algn1/reads>100)|(mis_algn2/RPM>100)),]
	SM1[,t1			:=	(reads/reads_back)/(reads_IC/reads_BKIC)]
	SM1[,t2			:=	(RPM/RPM_back)/(RPM_IC/RPM_BKIC)]
	SM1				=	SM1[is.na(t1)|is.na(t2)|(t1>=2&t2>=2)]
	SM1[,c('t1','t2'):=	NULL]
#	SM1				=	SM1[!(((reads/reads_back)/(reads_IC/reads_BKIC))<2|((RPM/RPM_back)/(RPM_IC/RPM_BKIC))<2),]
	NanoIDlist		=	SM1[,mk2]
}
sub_get_NanoID_cutoff3=	function(BM1,patho1){
	BM				=	copy(BM1)
	BM[,mk3			:=	paste(SampleType,species_nano,sep="_"),];
	patho			=	copy(patho1);
	patho[,mk3		:=	paste(SampleType,patho,sep="_"),]
	patholist		=	patho[,mk3]
	SM1				=	BM[mk3 %chin% patholist];
	SM1				=	SM1[MicroSum>100&((rlaPct>1e-4&SampleType=="CSF")|(rlaPct>1e-4&SampleType=="respiratory")|(rlaPct>1e-3&SampleType=="urinary"))];
	SM1				=	SM1[!(brd_leak2/RPM>100),]
	SM1				=	SM1[!(mis_algn2/RPM>100),]

	SM1[,fold		:=	(RPM/RPM_back)/(RPM_IC/RPM_BKIC),]
	SM1[,foldIC		:=	RPM_IC/RPM,]
	SM1[,foldBK		:=	RPM_back/RPM,]
	SM1				=	SM1[((is.na(fold)|(fold>=2))&(foldBK<0.2)&(foldIC<10)&(SampleType!="CSF"))|((is.na(fold)|(fold>=2))&(foldBK<1.0)&((foldIC<100&species_nano=="Mycobacterium tuberculosis")|(foldIC<50&species_nano!="Mycobacterium tuberculosis"))&(SampleType=="CSF")),];
#	SM1				=	SM1[((is.na(t2)|(t2>=2))&(RPM_back/RPM<0.2)&(RPM_IC/RPM<10)&(SampleType!="CSF"))|((is.na(t2)|(t2>=2))&(RPM_back/RPM<1.0)&(RPM_IC/RPM<50)&(SampleType=="CSF"))]
	SM1[,c('fold','foldIC','foldBK')	:=	NULL];
	NanoIDlist		=	SM1[,mk2]
}
sub_get_NanoID_cutoff=	function(BM,patho){
	SM1				=	BM[species_nano %chin% patho,];
	setorder(SM1,mk,-N,-N1)
	SM1				=	SM1[,head(.SD,3),by=mk];
	SM1				=	SM1[((species_nano %chin% c("Streptococcus_pneumoniae","Haemophilus_influenzae")&mis_algn3<N*2)|(mis_algn3<N*1)),]
	SM1				=	SM1[N>=5&(rlaPct>=0.05|((absPct>5e2&SampleType=="B")|(absPct>5e4&SampleType=="S"))),]
	NanoIDlist		=	SM1[,mk2]
}
sub_get_NanoID_cutoffV1=function(BM,patho){
	SM1				=	BM[species_nano %chin% patho,];
	setorder(SM1,mk,-N,-N1)
	SM1				=	SM1[,head(.SD,3),by=mk];
	SM1				=	SM1[((species_nano %chin% c("Streptococcus_pneumoniae","Haemophilus_influenzae")&mis_algn3<N*2)|(mis_algn3<N*1))&(N>0.01*brd_leak),]
	SM1				=	SM1[N>=3&(rlaPct>=0.01),]
	NanoIDlist		=	SM1[,mk2]
}
################################
my_write		=	function(OUT1,NM){
	tmp			=	names(OUT1)
	write.xlsx(OUT1[[tmp[1]]],	file=NM,	col.names=T, row.names=F, showNA=F, sheetName=tmp[1],append=F);
	if(length(tmp)>1){
	for(i in	2:length(tmp)){
	write.xlsx(OUT1[[tmp[i]]],	file=NM,	col.names=T, row.names=F, showNA=F, sheetName=tmp[i],append=T);
	}
	}
}
################################
get_BcdLeak_Misaln=	function(BM0){
	BM2			=	copy(BM0[,.(mk=mk,RunID_B=RunID,BCID_B=BCID,species_B=species_nano,reads_B=reads,RPM_B=RPM)])
	brd_leak1	=	rep(0,nrow(BM0))
	mis_algn1	=	rep(0,nrow(BM0))
	brd_leak2	=	rep(0,nrow(BM0))
	mis_algn2	=	rep(0,nrow(BM0))
	for(i in 1:nrow(BM0)){
		A		=	BM0[i,]
		B		=	BM2[RunID_B==A$RunID & !(BCID_B %chin% A$BCID)];# barcode leaking ones
		C		=	BM2[RunID_B==A$RunID &   BCID_B %chin% A$BCID,] # misalign ones
		spe		=	A$species_nano
		genus	=	unlist(strsplit(spe,split=" "))[1];
		brd_leak1[i]=	B[species_B ==	spe,sum(reads_B)];
		brd_leak2[i]=	B[species_B ==	spe,sum(RPM_B)];
		mis_algn1[i]=	C[grepl(genus,species_B)&species_B!=spe,sum(reads_B)];
		mis_algn2[i]=	C[grepl(genus,species_B)&species_B!=spe,sum(RPM_B)];
	}
	OUT			=	setDT(list(brd_leak1=brd_leak1,mis_algn1=mis_algn1,brd_leak2=brd_leak2,mis_algn2=mis_algn2));
}
################################
sub_comparison		=	function(BM,CUL,PCR,PathoIDlist){
	SampleType		=	BM[,.(SampleType=unique(SampleType)),by=mk]
	mk2list			=	union(union(CUL$mk2,PCR$mk2),BM$mk2)
	setkey(BM,mk2);setkey(CUL,mk2);setkey(PCR,mk2);
	BM1				=	BM[mk2list,]
	CUL1			=	CUL[mk2list,.SD[,-c('mk2')]]
	PCR1			=	PCR[mk2list,.SD[,-c('mk2')]]
	MX				=	cbind(BM1,CUL1,PCR1);
	setorder(MX,mk)
    my_fuc1         =   function(x){y=unlist(strsplit(x,split=";"));out=list(mk=paste(y[1:(length(y)-1)],collapse=";"),species=y[length(y)]);out}
    MX[,c('mk','pseudo_spe'):= my_fuc1(mk2),by=mk2]
    setorder(MX,mk)
	MX[,SampleType	:=	NULL,]
	MX				=	SampleType[MX,on='mk']

	MX[,nanoans		:=	ifelse(mk2 %chin% PathoIDlist,'pos','neg')];
	MX[is.na(species_cul),culans:='neg']
	MX[is.na(species_pcr),pcrans:='wait']
	MX[,CULcmpNANO	:=	ifelse(culans=="pos"&nanoans=="pos","culposnanopos;TP",
						ifelse(culans=="pos"&nanoans=="neg","culposnanoneg;FN",
						ifelse(culans=="neg"&nanoans=="pos","culnegnanopos;FP",
						ifelse(culans=="neg"&nanoans=="neg","culnegnanoneg;TN",'wrong'))))]
	MX[,.N,by=c('culans','nanoans','CULcmpNANO')]
	MX[,PCRcmpNANO	:=	ifelse(pcrans=="pos"&nanoans=="pos","pcrposnanopos;TP",
						ifelse(pcrans=="pos"&nanoans=="neg","pcrposnanoneg;FN",
						ifelse(pcrans=="neg"&nanoans=="pos","pcrnegnanopos;FP",
						ifelse(pcrans=="neg"&nanoans=="neg","pcrnegnanoneg;TN",
						ifelse(pcrans=="wait"&nanoans=="pos",'pcrwaitnanopos;FPwait',
						ifelse(pcrans=="wait"&nanoans=="neg",'pcrwaitnanoneg;FNwait','wrong'))))))]
	MX[,.N,by=c('pcrans','nanoans','PCRcmpNANO')]
	MX[,C_PcmpNANO	:=	ifelse(culans=="pos"&pcrans=="pos"	&nanoans=="pos","culposnanopos;TP",
						ifelse(culans=="pos"&pcrans=="pos"	&nanoans=="neg","culposnanoneg;FN",
						ifelse(culans=="pos"&pcrans=="neg"	&nanoans=="pos","culposnanopos;TP",
						ifelse(culans=="pos"&pcrans=="neg"	&nanoans=="neg","culposnanoneg;TN",
						ifelse(culans=="pos"&pcrans=="wait"	&nanoans=="pos","culposnanopos;TP",
						ifelse(culans=="pos"&pcrans=="wait"	&nanoans=="neg","culposnanoneg;FNwait",
						ifelse(culans=="neg"&pcrans=="pos"	&nanoans=="pos","culnegnanopos;TP",
						ifelse(culans=="neg"&pcrans=="pos"	&nanoans=="neg","culnegnanoneg;TN",
						ifelse(culans=="neg"&pcrans=="neg"	&nanoans=="pos","culnegnanopos;FP",
						ifelse(culans=="neg"&pcrans=="neg"	&nanoans=="neg","culnegnanoneg;TN",
						ifelse(culans=="neg"&pcrans=="wait"	&nanoans=="pos","culnegnanopos;FPwait",
						ifelse(culans=="neg"&pcrans=="wait"	&nanoans=="neg","culnegnanoneg;TN",'wrong'))))))))))))]
	MX[,.N,by=c('culans','pcrans','nanoans','C_PcmpNANO')]
    mks             =   MX$mk %>% sort %>% unique
	anno			=	lapply(mks,sub_SMP_collapse,MX=MX) %>% rbindlist
	MX1				=	anno[MX,on='mk']
	MX1;
}
sub_SMP_collapse	=	function(mk_i,MX){
	tmp				=	MX[mk==mk_i,]
	#compare cul vs nano
	tmp1			=	tmp[,CULcmpNANO]	%>% unique	
	CULCMPNANO		=	ifelse(any(grepl("TP$",tmp1)),'culPOSnanoPOSshareIDs;TP',
						ifelse(any(grepl("FP$",tmp1))&any(grepl("FN$",tmp1)),'culPOSnanoPOSdistinctIDs;FP',
						ifelse(any(grepl("FP$",tmp1)),'culNEGnanoPOS;FP',
						ifelse(any(grepl("FN$",tmp1)),'culPOSnanoNEG;FN',
						ifelse(all(grepl("TN$",tmp1)),'culNEGnanoNEG;TN','wrong')))));
	#compare pcr vs nano
	tmp1			=	tmp[,PCRcmpNANO]	%>% unique	
	PCRCMPNANO		=	ifelse(any(grepl("TP$",		tmp1)),							'pcrPOSnanoPOSshareIDs;TP',
						ifelse(any(grepl("FPwait$",	tmp1))&any(grepl("FN",tmp1)),	'pcrPOSnanoPOSwaitIDs;FPwait',
						ifelse(any(grepl("FPwait$",	tmp1)),							'pcrWAITnanoPOS;FPwait',
						ifelse(any(grepl("FNwait$",	tmp1)),							'pcrWAITnanoNEG;FNwait',
						ifelse(any(grepl("FP$",		tmp1))&any(grepl("FN$",tmp1)),	'pcrPOSnanoPOSdistinctIDs;FP',
						ifelse(any(grepl("FP$",		tmp1)),							'pcrNEGnanoPOS;FP',
						ifelse(any(grepl("FN$",		tmp1)),							'pcrPOSnanoNEG;FN',
						ifelse(all(grepl("TN$",		tmp1)),							'pcrNEGnanoNEG;TN','wrong'))))))));
	#compare cul vs nano vs pcr 
	tmp1			=	tmp[,C_PcmpNANO]	%>% unique
	C_PCMPNANO		=	ifelse(any(grepl("TP$",tmp1))&any(grepl("culposnanopos",tmp1)),										'culPOSnanoPOSshareIDs;TP',
						ifelse(any(grepl("TP$",tmp1))&any(grepl("culpos",tmp1)),											'culPOSnanoPOSdistinctIDs;TP',
						ifelse(any(grepl("TP$",tmp1))&all(grepl("culneg",tmp1)),											'culNEGnanoPOSrightIDs;TP',
						ifelse(any(grepl("FPwait$",tmp1))&any(grepl("culpos",tmp1)),										'culPOSnanoPOSwaitIDs;FPwait',
						ifelse(any(grepl("FPwait$",tmp1))&all(grepl("culneg",tmp1)),										'culNEGnanoPOSwaitIDs;FPwait',
						ifelse(any(grepl("FP$",tmp1))&any(grepl("culpos",tmp1))&any(grepl("FNwait$",tmp1)),					'culPOSnanoPOSwaitIDs;FNwait',
						ifelse(any(grepl("FP$",tmp1))&any(grepl("culpos",tmp1))&any(grepl("FN$",tmp1)),						'culPOSnanoPOSdistinctIDs;FP',			
						ifelse(any(grepl("FP$",tmp1))&any(grepl("culpos",tmp1))&any(grepl("TN$",tmp1)),						'culPOSnanoPOSwrongCulwrongIDs;FP',
						ifelse(any(grepl("FP$",tmp1))&all(grepl("culneg",tmp1)),											'culNEGnanoPOSwrongIDs;FP',
						ifelse(any(grepl("FNwait$",tmp1))&any(grepl("culpos",tmp1)),										'culPOSnanoNEGwaitIDs;FNwait',
						ifelse(any(grepl("FN$",tmp1))&any(grepl("culpos",tmp1)),											'culPOSnanoNEGmissedIDs;FN',
						ifelse(any(grepl("TN$",tmp1))&any(grepl("culpos",tmp1)),											'culPOSnanoNEGwrongCul;TN',
						ifelse(any(grepl("TN$",tmp1))&all(grepl("culneg",tmp1)),											'culNEGnanoNEG;TN','wrong')))))))))))));
	out				=	setDT(list(mk=mk_i,CULCMPNANO=CULCMPNANO,PCRCMPNANO=PCRCMPNANO,C_PCMPNANO=C_PCMPNANO))
}
sub_statistic_table2	=	function(SMP_table,SampleType=c("B","S")){
	label_lvl	=	c(	'culPOSnanoPOSshareIDs;TP',
						'culPOSnanoPOSdistinctIDs;TP',
						'culNEGnanoPOSrightIDs;TP',
						'culPOSnanoPOSwaitIDs;FPwait',
						'culNEGnanoPOSwaitIDs;FPwait',
						'culPOSnanoPOSwaitIDs;FNwait',
						'culPOSnanoPOSdistinctIDs;FP',			
						'culPOSnanoPOSwrongCulwrongIDs;FP',
						'culNEGnanoPOSwrongIDs;FP',
						'culPOSnanoNEGwaitIDs;FNwait',
						'culPOSnanoNEGmissedIDs;FN',
						'culPOSnanoNEGwrongCul;TN',
						'culNEGnanoNEG;TN')
	markers		=	rep("",length(SampleType)*length(label_lvl))
	for(i in 1:length(SampleType)){
	for(j in 1:length(label_lvl)){
	markers[(i-1)*length(label_lvl)+j]	=	paste(SampleType[i],label_lvl[j],sep=";")	
	}
	}
	tmp1		=	as.data.table(matrix(unlist(strsplit(markers,split=";")),ncol=3,byrow=T))
	markers		=	setDT(list(mk=markers))
	markers		=	cbind(markers,tmp1)
	SMP_table2	=	SMP_table[markers,on='mk']
	SMP_table2[is.na(N),N:=0,];
	SMP_table2[,SampleType	:=	V1]
	SMP_table2[,culans		:=	ifelse(grepl("culPOS",V2),"pos",ifelse(grepl("culNEG",V2),"neg","wrong"))]
	SMP_table2[,nanoans		:=	ifelse(grepl("nanoPOS",V2),"pos",ifelse(grepl("nanoNEG",V2),"neg","wrong"))]
	SMP_table2[,ANS			:=	V3]
	SMP_table2[,detail		:=	V2]
	SMP_table2[,c('V1','V2','V3','mk'):=NULL];
	setorder(SMP_table2,SampleType,culans,nanoans,ANS)
	SMP_table2[,yesCUL		:=	ifelse(culans==nanoans,1.0,0.0)]
	SMP_table2[,yesC_P		:=	ifelse(grepl('^T',ANS),1.0,0.0)]
	SMP_table2[,yesTP		:=	ifelse(grepl('^TP',ANS),1.0,0.0)]
	SMP_table2[,yesFP		:=	ifelse(grepl('^FP',ANS),1.0,0.0)]
	SMP_table2[,yesFN		:=	ifelse(grepl('^FN',ANS),1.0,0.0)]
	SMP_table2[,yesTN		:=	ifelse(grepl('^TN',ANS),1.0,0.0)]
	SMP_table2[,N_SMP		:=	sum(N),by=c('SampleType')]
	SMP_table2[,N_SMP_CUL	:=	sum(N),by=c('SampleType','culans')]
	SMP_table2[,N_SMP_CUL_NANO	:=	sum(N),by=c('SampleType','culans','nanoans')];
	SMP_table2[,N_SMP_CUL1		:=	sum(N*yesCUL),by=c('SampleType','culans')];
	SMP_table2[,N_SMP_C_P1		:=	sum(N*yesC_P),by=c('SampleType','culans')];
	SMP_table2[,P_SMP_CUL1		:=	round(N_SMP_CUL1/N_SMP_CUL*100,1),by=c('SampleType','culans')];
	SMP_table2[,P_SMP_C_P1		:=	round(N_SMP_C_P1/N_SMP_CUL*100,1),by=c('SampleType','culans')];
	SMP_table2[,P_CUL_CUL1		:=	round(sum(N_SMP_CUL1)/sum(N_SMP_CUL)*100,1),by=culans];
	SMP_table2[,P_CUL_C_P1		:=	round(sum(N_SMP_C_P1)/sum(N_SMP_CUL)*100,1),by=culans];
	SMP_table2[,Con_Cul2		:=	paste(P_CUL_CUL1,"% (",sum(N*yesCUL),"/",sum(N),")",sep=""),by=culans]
	SMP_table2[,Con_CulPCR2		:=	paste(P_CUL_C_P1,"% (",sum(N*yesC_P),"/",sum(N),")",sep=""),by=culans]
	SMP_table2[,SampleType		:=	paste(SampleType,"(",N_SMP,")",sep="")]
	SMP_table2[,culans			:=	paste(culans,"(",N_SMP_CUL,")",sep="")]
	SMP_table2[,nanoans			:=	paste(nanoans,"(",N_SMP_CUL_NANO,")",sep="")]
	SMP_table2[,Con_Cul			:=	paste(P_SMP_CUL1,"% (",N_SMP_CUL1,"/",N_SMP_CUL,")",sep="")]
	SMP_table2[,Con_CulPCR		:=	paste(P_SMP_C_P1,"% (",N_SMP_C_P1,"/",N_SMP_CUL,")",sep="")]

	SMP_table2[,TP				:=	sum(yesTP*N),]
	SMP_table2[,FP				:=	sum(yesFP*N),]
	SMP_table2[,FN				:=	sum(yesFN*N),]
	SMP_table2[,TN				:=	sum(yesTN*N),]
	SMP_table2[,sen				:=	round(sum(yesTP*N)/sum(yesTP*N+yesFN*N)*100,1),];
	SMP_table2[,spe				:=	round(sum(yesTN*N)/sum(yesTN*N+yesFP*N)*100,1),];
	SMP_table2[,ppv				:=	round(sum(yesTP*N)/sum(yesTP*N+yesFP*N)*100,1),];
	SMP_table2[,npv				:=	round(sum(yesTN*N)/sum(yesTN*N+yesFN*N)*100,1),];
	SMP_table2[,TP0				:=	sum(yesTP*N),by=SampleType]
	SMP_table2[,FP0				:=	sum(yesFP*N),by=SampleType]
	SMP_table2[,FN0				:=	sum(yesFN*N),by=SampleType]
	SMP_table2[,TN0				:=	sum(yesTN*N),by=SampleType]
	SMP_table2[,sen0			:=	round(sum(yesTP*N)/sum(yesTP*N+yesFN*N)*100,1),by=SampleType];
	SMP_table2[,spe0			:=	round(sum(yesTN*N)/sum(yesTN*N+yesFP*N)*100,1),by=SampleType];
	SMP_table2[,ppv0			:=	round(sum(yesTP*N)/sum(yesTP*N+yesFP*N)*100,1),by=SampleType];
	SMP_table2[,npv0			:=	round(sum(yesTN*N)/sum(yesTN*N+yesFN*N)*100,1),by=SampleType];
	SMP_table2					=	SMP_table2[,.SD[,c('SampleType','culans','nanoans','N','ANS','detail','Con_Cul','Con_CulPCR','Con_Cul2','Con_CulPCR2','sen','spe','ppv','npv','TP','FP','FN','TN','sen0','spe0','ppv0','npv0','TP0','FP0','FN0','TN0')]]
}
sub_get_SMPout	=	function(BM_ID){
	setorder(BM_ID,mk,species_nano)
	part1		=	BM_ID[nanoans=="pos"|culans=="pos",]
	part2		=	BM_ID[!mk %chin% part1$mk,head(.SD,1),by=mk]
	tmp			=	rbind(part1,part2)
	tmp[,out_nano:=	ifelse(is.na(species_nano),NA,paste(species_nano,reads,round(rlaPct*100,2),gsub(";",":",C_PcmpNANO),sep=":"))];
	tmp[,out_pcr:=	ifelse(is.na(species_pcr) ,NA,paste(species_pcr,pcrans,sep=":"))	]
	setorder(tmp,mk,-reads,na.last=T)
	out			=	tmp[,.(	SampleType	=	head(SampleType,1),MicroSum=head(MicroSum,1),reads_IC=head(reads_IC,1),reads_back=head(reads_back,1),reads_BKIC=head(reads_BKIC,1),CULCMPNANO=head(CULCMPNANO,1),C_PCMPNANO=head(C_PCMPNANO,1),
							out_nano	=	paste(na.omit(unique(out_nano)),collapse=";"),out_pcr=paste(na.omit(sort(unique(out_pcr))),collapse=";")),by=mk]
	#out			=	list(SMPlvl=out,SPElvl=tmp)
	out
}
###############################################################################################################################################################################
