import re
import os, sys
import pandas as pd
import  argparse

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2_bracken result NC relative abundance statistic.')
    parser.add_argument('--sample', help='A sample file as an input file.', type=str, required=True)
#    parser.add_argument('--NC_IC', help='A series of NC_IC bracken results.', type=str, nargs= "+")
    parser.add_argument('--result', help='A series of results csv files', type = str, nargs= "+")
    parser.add_argument('--output', help='An output file to save the normalized results.', type=str, required=True)
#    parser.add_argument('--output1', help='An output file to save final results, default as xlsx format.', type=str,
#                        required=True)
#    parser.add_argument("--output2", help="An output file to the blast statistic result.", type=str)
    #    parser.add_argument('--chimera', help="A directory contained all the chimera results.", type=str, required = True)
    #    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return (args)
def df_merge(*args):
    result = pd.DataFrame()
    for fi in args:
        for j in fi:
            df = pd.read_excel(j)
            result = pd.concat([result, df], sort = True)
    return(result)
def main():
    args = parse_input()
    df = df_merge(args.result)
    sample = pd.read_excel(args.sample, sheet_name=1)
    sample.rename(columns={"样本文库编号": "sample"}, inplace= True)
    result = pd.merge(sample, df, on = "sample", how = "outer")
    result = result[["sample", "临床结果", "species", "reads", "abundance"]]
    result.to_excel(args.output, index = False)
    return ("Finished the analysis.")
if __name__ == "__main__":
    main()

