import pandas as pd
import os, sys
import argparse
import re
import multiprocessing
#def parse_input():
#    parser = argparse.ArgumentParser(description='Run the blast statistic, and generate the final result.')
#    parser.add_argument('-I', '--input', help='An input blast IC .', type=str, required = True)
#    parser.add_argument('-O','--output', help='An output file to save final results.', type=str, required = True)
#    parser.add_argument('', help="A config file contained all the categories' related information", type=str, required = True)
#    parser.add_argument('--creden', help='path to credentials; only the production environment is supported; '
#                                         'JSON FORMAT:'
#                                         '{"username":<username>,"password": <password>}',
#                        type=str, default='./creden/circlecn-credentials.json')
#    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
#    if len(sys.argv) == 1:
#        parser.print_help()
#        sys.exit(1)
#
#    args = parser.parse_args()
#    return args
data1 = pd.read_csv(sys.argv[1], sep = '\t', header = None)
data2 = pd.read_csv(sys.argv[2], sep = '\t', header = None)
labels = ['tag', 'length', 'match_start', 'match_end', 'seqid', 'species_length', 'start', 'end', \
          'bitscore', 'taxid', 'species', 'genus','ident']
Labels = {}
for i in range(len(labels)):
    Labels[i] = labels[i]
data1.rename(columns = Labels, inplace = True)
data2.rename(columns = Labels, inplace = True)
data = pd.concat([data1, data2], sort = False)
bitscore = pd.DataFrame(data['bitscore'].groupby(data['tag']).max() * 0.95)
bitscore.reset_index([0], inplace = True)
bitscore.rename(columns = {'bitscore': 'stand'}, inplace = True)
data_1 = pd.merge(data, bitscore, on = 'tag')
data_1['bitvalue'] = data_1['bitscore'] - data_1['stand']
data_2 = data_1[data_1['bitvalue'] >= 0]
data_3 = pd.DataFrame(data_2.groupby(['tag','genus'])[['genus']].count())
data_4 = pd.DataFrame(data_2.groupby(['tag','species'])[['species']].count())
data_3.reset_index([0], inplace = True)
data_4.reset_index([0], inplace = True)
data_3.rename(columns = {'genus': 'count'}, inplace = True)
data_4.rename(columns = {'species': 'count'}, inplace = True)
data_3.reset_index([0], inplace = True)
data_4.reset_index([0], inplace = True)
data3 =  data_3.drop_duplicates(subset=['tag'], keep = False)
data4 =  data_4.drop_duplicates(subset=['tag'], keep = False)
Genus = pd.DataFrame(data3[data3['count'] > 1]['genus'].value_counts())
Species = pd.DataFrame(data4[data4['count'] == 1]['species'].value_counts())
Genus.rename(columns = {'genus': 'count'}, inplace = True)
Species.rename(columns = {'species': 'count'}, inplace = True)
Genus.reset_index([0], inplace = True)
Species.reset_index([0], inplace = True)
Genus['genus'] = Genus['index'] + '.sp'
Genus.rename(columns = {'genus': 'species'}, inplace = True)
Genus.drop(['index'], axis = 1, inplace = True)
Species.rename(columns = {'index': 'species'}, inplace = True)
output = pd.concat([Species, Genus], sort = False )
output.sort_values(by = 'count', ascending=False)
output.to_csv(sys.argv[3], sep = '\t', index = False)

