#! /bin/bash
fasta=$1;
IC_blast=$2;
output=$3;
path1=${IC_blast%/*};
name1=${output##*/};
name=${name1%%.*};
cut -f 1 $IC_blast | sort -u > $path1/$name".rdid1";
awk '$1~/^>/{gsub(">","",$1);print $1}' $fasta | sort -u > $path1/$name".rdid0";
comm -23  $path1/$name".rdid0"  $path1/$name".rdid1" > $path1/$name".rdid2";
seqtk subseq $fasta $path1/$name".rdid2" > $output
