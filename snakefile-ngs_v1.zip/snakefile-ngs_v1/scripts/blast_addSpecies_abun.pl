#!/usr/bin/perl 

my($ic_blast, $microbial_blast, $addSpecies_out, $abun_out, $taxdb, $taxDB, $seqid2taxid) = @ARGV;
# my $taxdb="/gpfsdata/users/liangxz/work/20.NGS/db/taxonomy/taxDB.topo";
# my $taxDB="/gpfsdata/database/genomes/taxidList/NCBI_database/taxonomy/2020-01-21/taxDB";
# my $seqid2taxid="/gpfsdata/users/liangxz/work/4.Respiratory_pathogen/23.NTv5_seqid2taxid/3.microbial_nt_db/blast_addHuman/microbial_nt_addHuman.seqid2taxid";


my(%taxdb, %taxDB, %seqid2taxid, %blast);
&get_taxonomy($seqid2taxid, $taxdb, \%seqid2taxid, \%taxdb);
&get_taxdb($taxDB, \%taxDB);

&get_blast($ic_blast, $microbial_blast, $addSpecies_out, \%blast, \%seqid2taxid, \%taxdb);



my ($total_reads, %count);
foreach my $key(keys %blast){
    $total_reads ++;
    my @kingdom = split(/;/, $blast{$key}{"kingdom"});
    my @genus   = split(/;/, $blast{$key}{"genus"});
    my @species = split(/;/, $blast{$key}{"species"});
    
    my %uniq;
    @kingdom = grep { ++$uniq{$_} < 2; } @kingdom;
    @genus   = grep { ++$uniq{$_} < 2; } @genus;
    @species = grep { ++$uniq{$_} < 2; } @species;

    if(@kingdom < 2 && $kingdom[0] ne "Viruses"){
        if(@genus < 2){
            for (my $j = 0; $j < @species; $j ++){
                $count{$species[$j]} += 1/@species;
            }
        }
    }elsif(@kingdom < 2 && $kingdom[0] eq "Viruses"){
        for (my $j = 0; $j < @species; $j ++){
            $count{$species[$j]} += 1/@species;
        }   
    }
}

open OUT, ">$abun_out" || die;
foreach my $key(sort{$count{$b} <=> $count{$a}} keys %count){
    my $abun  = sprintf "%.5f", 100*$count{$key}/$total_reads;
    my $count = sprintf "%.f", $count{$key};
    print OUT "$key\t$taxDB{$key}\t$count\t$abun\n";
}
close OUT;

#################
sub get_taxdb{
    my($file, $hash) = @_;
    open TMP5, $file || die;
    while(<TMP5>){
        chomp;
        my($taxid, $species, $rank) = (split(/\t/))[0,2,3];
        if($rank eq "species"){
            $$hash{$species} = $taxid;
        }
    }
    close TMP5;
}


sub get_blast{
    my($file1, $file2, $out, $hash1, $hash2, $hash3) = @_;
    open TMP3, $file1 || die;
    open TMP4, $file2 || die;
    open TMPOUT, ">$out"||die;
    
    my $maxbitscore; 
    while(<TMP3>){
        chomp;
        my @arr = split(/\t/);
        my $info1  = join("\t", @arr[0..8]);
        my $info2  = join("\t", @arr[12..13]);
        my $taxid  = $$hash2{$arr[4]};
        my $species= $$hash3{$$hash2{$arr[4]}}{"species"};
        my $genus  = $$hash3{$$hash2{$arr[4]}}{"genus"};
        my $kingdom= $$hash3{$$hash2{$arr[4]}}{"superkingdom"};

        if(!exists $$hash1{$arr[0]}){
            $$hash1{$arr[0]}{"genus"}   = $genus;
            $$hash1{$arr[0]}{"species"} = $species;
            $$hash1{$arr[0]}{"kingdom"} = $kingdom;
            $maxbitscore = $arr[8];
            print TMPOUT "$info1\t$taxid\t$species\t".$$hash3{$taxid}{"superkingdom"}."\t$info2\n";
        }else{
            if($arr[8] >= $maxbitscore * 0.95){
                $$hash1{$arr[0]}{"genus"}   .= ";".$genus;
                $$hash1{$arr[0]}{"species"} .= ";".$species;
                $$hash1{$arr[0]}{"kingdom"} .= ";".$kingdom;
                print TMPOUT "$info1\t$taxid\t$species\t".$$hash3{$taxid}{"superkingdom"}."\t$info2\n";         
            }
        }
    }

    while(<TMP4>){
        chomp;
        my @arr = split(/\t/);
        my $info1  = join("\t", @arr[0..8]);
        my $info2  = join("\t", @arr[12..$#arr]);
        my $taxid  = $$hash2{$arr[4]};
        my $species= $$hash3{$$hash2{$arr[4]}}{"species"};
        my $genus  = $$hash3{$$hash2{$arr[4]}}{"genus"};

        if(!exists $$hash1{$arr[0]}){
            $$hash1{$arr[0]}{"genus"}   = $genus;
            $$hash1{$arr[0]}{"species"} = $species;
            $maxbitscore = $arr[8];
            print TMPOUT "$info1\t$taxid\t$species\t".$$hash3{$taxid}{"superkingdom"}."\t$info2\n";
        }else{
            if($arr[8] >= $maxbitscore * 0.95){
                $$hash1{$arr[0]}{"genus"}   .= ";".$genus;
                $$hash1{$arr[0]}{"species"} .= ";".$species;
                print TMPOUT "$info1\t$taxid\t$species\t".$$hash3{$taxid}{"superkingdom"}."\t$info2\n";        
            }
        }
    }
    close TMP3;
    close TMP4;
    close TMPOUT;
}

sub get_taxonomy{
    my($file1, $file2, $hash1, $hash2) = @_;

    my %have;
    open TMP1, $file1 || die;
    while(<TMP1>){
        chomp;
        my($seqid, $taxid) = (split(/\t/))[0,1];
        $$hash1{$seqid} = $taxid;
        $have{$taxid} = 1;
    }
    close TMP1;

    open TMP2, $file2 || die;
    while(<TMP2>){
        chomp;
        my($taxid, $lineages, $lineages_name, $lineages_rank) = (split(/\t/))[0,1,3,4];
        if(exists $have{$taxid}){
            my @lineages_rank = split(/,/, $lineages_rank);
            my @lineages_name = split(/,/, $lineages_name);
            for (my $i = 0; $i < @lineages_rank; $i ++){
                if($lineages_rank[$i] eq "species"){
                    $$hash2{$taxid}{"species"} = $lineages_name[$i];
                }elsif($lineages_rank[$i] eq "genus"){
                    $$hash2{$taxid}{"genus"} = $lineages_name[$i];
                }elsif($lineages_rank[$i] eq "superkingdom"){
                    $$hash2{$taxid}{"superkingdom"} = $lineages_name[$i];
                }
            }
        }
    }
    close TMP2;
}