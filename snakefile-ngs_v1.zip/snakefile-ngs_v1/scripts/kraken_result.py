import pandas as pd
import os, sys
import argparse
import copy
def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2_bracken result NC relative abundance statistic.')
    parser.add_argument('--kraken', help='A series of kraken results.', type=str, required=True)
    parser.add_argument('--sample', help='A sample information tsv file, contained all the information needed in analysis.', type=str, required=True)
    parser.add_argument("--final", help = "An output to save the final results after filter.", type=str, required= True)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
    args = parser.parse_args()
    return args
def merge_arrange(args):
#    result = pd.DataFrame()
    result = {}
    for dirpath, dirname, files  in os.walk(args):
        for fi in files:
            if fi.endswith(".csv") or fi.endswith("tsv"):
                with open(os.path.join(dirpath, fi)) as f:
                    for line in f:
                        ls = line.strip("\n").split("\t")
                        if ls[0] not in result:
                            result[ls[0]] = {"result":[]}
                        if ls[1] != "":
                            result[ls[0]]["result"].append(ls[1])
                        if ls[2] != "":
                            result[ls[0]]["result"].append(ls[2])
#                data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
#                result = pd.concat([result, data], sort = True)
#    species = result.groupby("sample")["species_result"].apply(lambda x:x.str.cat(sep=';')).reset_index()
#    genus = result.groupby("sample")["genus_result"].apply(lambda x:x.str.cat(sep=';')).reset_index()
#    output = pd.merge(species,genus, on = "sample", how = "left")
#    output = output[["sample", "species_result", "genus_result"]]
#    return (output)
    return (result)
def main():
    args = parse_input()
    data = merge_arrange(args.kraken)
#    sample = pd.read_csv(args.sample, sep = "\t")
#    print (sample["samples"].count())
#    result = pd.merge(sample, data, left_on = "samples", right_on= "sample", how = "left")
#    result = result[["sample", "type", "culture", "culture_others", "species_result", "genus_result"]]
#    result = result[result["sample"].notnull()]
#    result.to_csv(args.final, index = False, sep = "\t")
    rawdata = {}
    with open(args.sample, "r") as f:
        tags = f.readline().strip("\n").split("\t")
        for line in f:
            ls = line.strip("\n").split("\t")
#            for j in tags[1:]:
#                pos = tags.index(j)
#                rawdata[ls[0]] = {j: ls[pos]}
            rawdata[ls[1]] = ls
    for i in sorted(rawdata.keys()):
 #       rawdata[i]["genus_result"] = ""
        if i in data.keys():
            rawdata[i].append(";".join(sorted(set(data[i]["result"]))))
    with open(args.final, "w") as w:
        w.write("##originid\tsample\tbatchID\ttype\tlibrary\tculture\tculture_others\tresult\n")
        for i in sorted(rawdata.keys()):
            w.write("\t".join(rawdata[i][:]) + "\n")
    return (True)
if __name__ == "__main__":
    main()
