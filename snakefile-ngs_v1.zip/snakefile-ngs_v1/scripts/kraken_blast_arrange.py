import pandas as pd
import re
import os, sys

result = {}
for dirpath, dirname, files in os.walk(sys.argv[1]):
    for fi in files:
        if fi.endswith("final.bracken") or fi.endswith("abundance.tsv"):
            name = fi.split(".")[0]
            data = pd.read_csv(os.path.join(dirpath, fi), sep = '\t')
            result[name] = data

xlsx = pd.ExcelWriter(sys.argv[2])
for i in sorted(result.keys()):
    result[i].to_excel(xlsx, sheet_name = i, index = False)
print ("Finish the excel save work.")
xlsx.close()