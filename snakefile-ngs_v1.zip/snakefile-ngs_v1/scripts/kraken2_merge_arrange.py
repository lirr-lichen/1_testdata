import os, sys
import pandas as pd
import argparse
import re
import copy

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2_bracken result add taxid, genus, superkingdom information.')
    parser.add_argument('--input', help='A series of kraken2/blast result files.', type=str, nargs= "+", required=True)
    parser.add_argument('--taxDB', help='A file contained all the taxid_species_genus information.', type=str, default="/gpfsdata/users/zhangyan/NGS_database_20200510/reference/taxDB.tsv")
    parser.add_argument("--output", help = "An output to save the final results.", type=str, required= True)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
    args = parser.parse_args()
    return args
def kraken_merge(args):
    result = pd.DataFrame()
    for dirpath, dirname, files in os.walk(args):
        for fi in files:
            if fi.endswith("final.bracken"):
                name = fi.split(".")[0]
                data = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                if "fraction_total_reads" in data.columns.tolist():
                    data["fraction_total_reads"] = data["fraction_total_reads"] * 100
                data.rename(columns={"name": "species", "taxonomy_id": "taxid", "new_est_reads": "reads","abun_total_reads(%)": "abundance"}, inplace=True)
                data.rename(columns={"fraction_total_reads": "abundance"}, inplace=True)  ## a few special samples
                data["sample"] = name
                data = data[["sample", "species", "taxid", "reads", "abundance"]]
                result = pd.concat([result, data], sort = True)
    result = result[["sample", "species", "taxid", "reads", "abundance"]]
    result.sort_values(by = "sample", inplace= True)
    return (result)
def taxDB_arrange(args):
#    result = {}
    result = {"taxid": [], "species": [], "genus_id": [], "genus": [], "superkingdom_id": [],"superkingdom": []}  # order by taxid, species, genus_id, genus, superkindom_id, superkindom
    with open(args, "r") as f:
        for line in f:
            line = line.strip()
            ls = line.split("\t")
            if ls[-1].startswith("species"):
 #               if ls[0] not in result:
 #                   result[ls[0]] = {"taxid":[], "species": [], "genus_id": [], "genus": [], "superkingdom_id": [], "superkingdom" : []} # order by taxid, species, genus_id, genus, superkindom_id, superkindom
                tax_list = ls[1].split(",")
                name_list = ls[3].split(",")
                level_list = ls[-1].split(",")
                if "species" in level_list and "genus" in level_list and "superkingdom" in level_list:
                    pos_species = level_list.index("species")
                    pos_genus = level_list.index("genus")
                    pos_superkingdom = level_list.index("superkingdom")
#                if level_list[0] == "species" and level_list[1] == "genus" and level_list[-3] == "superkingdom":
                    result["taxid"].append(int(tax_list[pos_species]))
                    result["species"].append(name_list[pos_species])
                    result["genus_id"].append(int(tax_list[pos_genus]))
                    result["genus"].append(name_list[pos_genus])
                    result["superkingdom_id"].append(int(tax_list[pos_superkingdom]))
                    result["superkingdom"].append(name_list[pos_superkingdom])
                if "species" in level_list and "superkingdom" in level_list and "genus" not in level_list:
                    pos_species = level_list.index("species")
#                    pos_genus = level_list.index("genus")
                    pos_superkingdom = level_list.index("superkingdom")
                    result["taxid"].append(int(tax_list[pos_species]))
                    result["species"].append(name_list[pos_species])
                    result["genus_id"].append(int(-1))
                    result["genus"].append("NA")
                    result["superkingdom_id"].append(int(tax_list[pos_superkingdom]))
                    result["superkingdom"].append(name_list[pos_superkingdom])

    output = pd.DataFrame(result, index = range(len(result["taxid"])))
    return (output)
def main():
    args = parse_input()
    kraken = pd.DataFrame()
    for i in args.kraken:
        data = kraken_merge(i)
        kraken = pd.concat([kraken, data], sort = True)
#    taxdb = taxDB_arrange(args.taxDB)
    taxdb = pd.read_csv(args.taxDB, sep = "\t")
    result = pd.merge(kraken, taxdb, on = ["taxid"], how="left")
    result.rename(columns={"species_x" : "species"}, inplace= True)
    output = copy.deepcopy(result[["sample", "species", "taxid", "genus", "superkingdom", "reads", "abundance"]])
    output.sort_values(by = "sample", inplace= True)
    output.to_csv(args.output, sep = "\t", index = False)
    return ("Finished the work.")
if __name__ == "__main__":
    main()
