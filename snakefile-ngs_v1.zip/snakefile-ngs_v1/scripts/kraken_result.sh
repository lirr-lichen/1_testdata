indir=$1;
output=$2;
#for i in 200502; do echo $i
echo -e "sample\tEscherichia virus Lambda\tEscherichia virus MS2\tHuman gammaherpesvirus 4\tEnterovirus A\tKlebsiella pneumoniae\tCryptococcus neoformans\tCryptococcus neoformans"   > $output;
for i in $(ls $indir/*IC.report)
  do
    echo $i;
    j=${i##*/};
    name=${j%%.*};
#for j in `cat $path2/$i/filelist|grep .fastq |grep R1`;do echo $j;j1=`echo $j|sed 's/.fastq.gz//g'`;echo $j1
#N0=`zcat $path2/$i/$j1.fastq.gz|wc -l|awk '{print $1/4}'`;
#N1=`wc -l $path1/$i"_150"/$j1.qc1.fastq|awk '{print $1/4}'`;
#N2=`wc -l $path1/$i"_150"/$j1.qc2.fastq|awk '{print $1/4}'`;
#N3=`wc -l $path1/$i"_150"/$j1.qc3.fastq|awk '{print $1/4}'`;
#N4=`wc -l $path1/$i"_150"/$j1.unmap4.fastq|awk '{print $1/4}'`;
#N5=`wc -l $path1/$i"_150"/$j1.unmap4.fasta|awk '{print $1/2}'`;
#N6=`wc -l $path1/$i"_150"/$j1.unmap5.fasta|awk '{print $1/2}'`;
#N7=`cat          $path1/$i"_150"/$j1.blast3|awk 'BEGIN{sum=0;}{sum=sum+$1}END{print sum}'`;
#echo -e "$j1\t$N0\t$N1\t$N2\t$N3\t$N4\t$N5\t$N6\t$N7"  >>      $path1/$i"_150"/reads_number.txt;
#done
    N0=$(cat $i | egrep "Escherichia virus Lambda" | cut -f2);
    N1=$(cat $i | egrep "Escherichia virus MS2" | cut -f2);

done