import os, sys
import pandas as pd
import numpy as np
#from pandas import DataFrame
import re
import argparse
import subprocess
import copy

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for nerve_ngs QC statistic.')
    parser.add_argument('--QC', help='An input directory contains QC log files(fastp, seqkit, cutadapt).', type=str, required = True)
    parser.add_argument('--rmhost', help='An input directory contains rmhost log files(the final rmhost4 log mainly needed).', type=str, required = True)
    parser.add_argument('--result', help='An input directory contains results files.', type=str, required = True)
#    parser.add_argument('--kraken', help='An input directory contains kraken results.', type=str, required = True)
    parser.add_argument('--output', help='An output file to save final results, default as tsv format.', type=str, required = True)
#    parser.add_argument('--chimera', help="A directory contained all the chimera results.", type=str, required = True)
#    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args
def fastp_result(args1):
    '''This is a function to extract the fastp log file, used for QC statistics.'''
    output = {'total_reads' : 0, 'qc1_reads': 0, 'low_quality_reads' : 0, 'too_short_reads' : 0, 'adapter_trimmed_reads' : 0 } # set the default values of each object
    with open(args1) as f:
        content = f.read()
        m1 = re.findall('total reads:\s(\d+)', content) # only the first one is needed for count
        if len(m1) == 2:
            output['total_reads'] = int(m1[0])
            output['qc1_reads'] = int(m1[1])# transfer the format to int
        m3 = re.search('reads failed due to low quality:\s(\d+)', content)
        if m3:
            output['low_quality_reads'] = int(m3.groups()[0])
        m4 =  re.search('reads failed due to too short:\s(\d+)', content)
        if m4:
            output['too_short_reads'] = int(m4.groups()[0])
        m5 = re.search('reads with adapter trimmed:\s(\d+)', content)
        if m5:
            output['adapter_trimmed_reads'] = int(m5.groups()[0])
    result = pd.DataFrame(output, index = [0])
    return (result)
def cutadapt_result(args1):
    output = {'qc2_reads': 0, 'qc3_reads': 0}
    with open(args1) as f:
        for line in f:
            line = line.strip()
            if "Total reads processed" in line:
                qc2 = re.search(":\s+(.*)", line).groups()[0]
                qc2_reads = int(qc2.replace("," , ""))
                output['qc2_reads'] = qc2_reads
            if "Reads written" in line:
                qc3 = re.search(":\s+(.*)\s", line).groups()[0]
                qc3_reads = int(qc3.replace("," , ""))
                output["qc3_reads"] = qc3_reads
    result = pd.DataFrame(output, index = [0])
    return (result)
def rmhost_result(args1):
    output = {"rmhost_reads": 0}
    lines = subprocess.Popen("grep -c '@' {}".format(args1), shell=True, stdout=subprocess.PIPE)
    length = int(lines.stdout.readlines()[0].strip().decode())
    output["rmhost_reads"] = length
    result = pd.DataFrame(output, index=[0])
    return (result)
def kraken2_result(args1, args2):
    '''This is a function to extract the number of DNA_IC reads, RNA_IC reads, remaining human spaciens' reads after blasting.'''
    list1 = ['Escherichia virus Lambda', 'Escherichia virus MS2', 'Streptococcus pneumoniae','Influenza B virus']
    data = pd.read_csv(args1, sep = '\t')
    data = copy.deepcopy(data[["species", "reads", "abundance"]])
#    data.rename(columns = {"name": 'species', "new_est_reads": 'reads', "abun_total_reads(%)": 'abundance'}, inplace = True)
    if data["species"].count() == 0:
        result = {}
        for i in list1:
            result[i + "_" + args2] = 0
            result[i + "_abundance" + "_" + args2] = 0.0
#        result["Pseudomonas|Burkholderia"] = 0
#        result["Pseudomonas|Burkholderia_abundance"] = 0.0
#        result["kraken_reads"] = 0
        final = pd.DataFrame(result, index = [0])
    else:
        result = pd.DataFrame({'species': list1}, index = range(len(list1)))
        output = pd.merge(data[data['species'].isin(list1)],result, how = 'outer')
        output.fillna(0.0, inplace = True)
#        pollution = data[data['species'].str.contains('Pseudomonas|Burkholderia')]
#        output = output.append([{'species': 'Pseudomonas_Burkholderia', 'reads': pollution['reads'].sum(),'abundance': pollution['abundance'].sum()}])
        output.index = output['species']
        del output['species']
#        del output.index.name
        output.rename_axis(None, inplace=True)
#        output.rename(columns = {"reads": "reads" + "_"})
        reads = pd.DataFrame(output['reads'].to_dict(), index=[0])
        reads2 = {}
        for i in reads.keys():
            reads2[i + "_" + args2] = reads[i]
        reads3 = pd.DataFrame(reads2, index = [0])
        abundance = output['abundance'].to_dict()
        abundance2 = {}
        for i in abundance.keys():
            abundance2[i + "_abundance" + "_" + args2] = abundance[i]
        reads4 = pd.DataFrame(abundance2, index = [0])
#        reads3 = pd.DataFrame({'kraken_reads': data['reads'].sum()}, index = [0])
#        final1 = pd.concat([reads, reads2], axis = 1)
        final = pd.concat([reads3, reads4], axis = 1)
    #    final.fillna(0.0)
    return (final)
def seqkit_rmdup(args1):
    '''This is a function to extract the removed duplication reads number in the seqkit manipulation process.'''
    output = {'rmdup' : 0} # in default, set the rmdup as 0
    with open(args1) as f:
        line = f.readline().strip()
        output['rmdup'] = int(line.split()[1])
    result = pd.DataFrame(output, index = [0])
    return (result)
if __name__ == '__main__':
    args = parse_input()
    cutadapt = pd.DataFrame()
    fastp = pd.DataFrame()
    seqkit = pd.DataFrame()
#    chimera = pd.DataFrame()
    blast = pd.DataFrame()
    kraken = pd.DataFrame()
    bracken = pd.DataFrame()
#    kraken = pd.DataFrame()
    rmhost = pd.DataFrame()
    #Files = {} # define a dict to save all the samples' related files
    for dirpath, dirname, files in os.walk(args.QC):
         for fi in files:
            name = fi.split('.')[0]
            #if fi == 'reads_number.txt':
#            if fi == '':
#                    origin = pd.read_csv(os.path.join(dirpath, fi), sep = '\t')
            if fi.endswith('qc1.log'):
                dfout = fastp_result(os.path.join(dirpath, fi))
                dfout['sample'] = name
                fastp = pd.concat([fastp, dfout], sort = True)
            if fi.endswith('qc2.log'):
                dfout = seqkit_rmdup(os.path.join(dirpath, fi))
                dfout['sample'] = name
                seqkit = pd.concat([seqkit, dfout], sort = True)
            if fi.endswith('qc3.log'):
                dfout = cutadapt_result(os.path.join(dirpath, fi))
                dfout['sample'] = name
                cutadapt = pd.concat([cutadapt, dfout], sort = True)
    for dirpath, dirname, files in os.walk(args.rmhost):
        for fi in files:
            if fi.endswith("unmap4.fastq"):
                name = fi.split(".")[0]
                dfout = rmhost_result(os.path.join(dirpath, fi))
                dfout['sample'] = name
                rmhost = pd.concat([rmhost, dfout], sort = True)
    for dirpath, dirname, files in os.walk(args.result):
        for fi in files:
            if fi.endswith("kraken.origin.tsv"):
                name = fi.split(".")[0]
                dfout = kraken2_result(os.path.join(dirpath, fi), "kraken")
                dfout['sample'] = name
                kraken = pd.concat([kraken, dfout], sort = True)
            if fi.endswith("kraken.tsv"):
                name = fi.split(".")[0]
                dfout = kraken2_result(os.path.join(dirpath, fi), "bracken")
                dfout['sample'] = name
                bracken = pd.concat([bracken, dfout], sort=True)
            if fi.endswith("blast.tsv"):
                name = fi.split(".")[0]
                dfout = kraken2_result(os.path.join(dirpath, fi), "blast")
                dfout['sample'] = name
                blast = pd.concat([blast, dfout], sort=True)
    Arrange1 = pd.merge(pd.merge(fastp, seqkit, on = 'sample'), cutadapt, on = 'sample')
    Arrange2 = pd.merge(pd.merge(Arrange1, rmhost, on = 'sample'), kraken, on = 'sample', how = "outer")
    Arrange = pd.merge(pd.merge(Arrange2, bracken, on = "sample"), blast, on = "sample", how = "outer")
#    Arrange = pd.merge(Arrange2, chimera, on = 'sample')
    Arrange.fillna(0.0)
    Arrange['low_percent'] = Arrange['low_quality_reads']/Arrange['total_reads']
    Arrange['short_precent'] =  Arrange['too_short_reads'] /Arrange['total_reads']
    Arrange['adapter_precent'] = Arrange['adapter_trimmed_reads'] / Arrange['total_reads']
    Arrange['rmdup_precent'] = Arrange['rmdup'] / Arrange['total_reads']
    Arrange['reads_rm_percent'] = (Arrange['total_reads'] - Arrange['qc3_reads']) / Arrange['total_reads']
    Arrange['rmhost_percent'] = (Arrange['qc3_reads'] - Arrange['rmhost_reads']) / Arrange['qc3_reads']
#    Arrange['IC_percent'] = (Arrange['Escherichia virus Lambda'] + Arrange['Escherichia virus MS2']) / Arrange['blastN']
#    Arrange['No_IC_percent'] = (Arrange['blastN'] - Arrange['Escherichia virus Lambda'] - Arrange['Escherichia virus MS2']) / Arrange['blastN']
    for i in ['low_percent', 'short_precent', 'adapter_precent', 'rmdup_precent', 'reads_rm_percent', 'rmhost_percent']:
        Arrange[i] = Arrange[i].apply( lambda x: str(round(x * 100, 2)) + '%')
    for i in ['Escherichia virus Lambda_abundance_kraken', 'Escherichia virus MS2_abundance_kraken', 'Streptococcus pneumoniae_abundance_kraken','Influenza B virus_abundance_kraken']:
        Arrange[i] = Arrange[i].apply(lambda x : str(round (x, 2)) + "%")
    for i in ['Escherichia virus Lambda_abundance_bracken', 'Escherichia virus MS2_abundance_bracken', 'Streptococcus pneumoniae_abundance_bracken','Influenza B virus_abundance_bracken']:
        Arrange[i] = Arrange[i].apply(lambda x : str(round (x , 2)) + "%")
    for i in ['Escherichia virus Lambda_abundance_blast', 'Escherichia virus MS2_abundance_blast', 'Streptococcus pneumoniae_abundance_blast','Influenza B virus_abundance_blast']:
        Arrange[i] = Arrange[i].apply(lambda x : str(round (x, 2)) + "%")
    columns = ['sample','total_reads','low_quality_reads','too_short_reads','adapter_trimmed_reads','rmdup','qc1_reads','qc2_reads','qc3_reads','rmhost_reads','Escherichia virus Lambda_kraken','Escherichia virus MS2_kraken','Streptococcus pneumoniae_kraken', 'Influenza B virus_kraken','Escherichia virus Lambda_bracken','Escherichia virus MS2_bracken','Streptococcus pneumoniae_bracken', 'Influenza B virus_bracken','Escherichia virus Lambda_blast','Escherichia virus MS2_blast','Streptococcus pneumoniae_blast', 'Influenza B virus_blast','low_percent', 'short_precent', 'adapter_precent', 'rmdup_precent', 'reads_rm_percent', 'rmhost_percent', \
               'Escherichia virus Lambda_abundance_kraken', 'Escherichia virus MS2_abundance_kraken','Streptococcus pneumoniae_abundance_kraken', 'Influenza B virus_abundance_kraken',\
               'Escherichia virus Lambda_abundance_bracken', 'Escherichia virus MS2_abundance_bracken', 'Streptococcus pneumoniae_abundance_bracken','Influenza B virus_abundance_bracken', \
               'Escherichia virus Lambda_abundance_blast', 'Escherichia virus MS2_abundance_blast', 'Streptococcus pneumoniae_abundance_blast','Influenza B virus_abundance_blast']
    Arrange = Arrange[columns]
#    Arrange.columns = ['sample', '总reads', '低质量reads', '长度过短reads', '含有adapter的reads', '去除的重复reads','qc1N', 'qc2N', 'qc3N', 'rmhostN', 'blastN', 'Escherichia virus Lambda', 'Escherichia virus MS2', 'Human gammaherpesvirus 4', 'Enterovirus A', 'Listeria monocytogenes', 'Klebsiella pneumoniae', 'Cryptococcus neoformans', 'Salmonella enterica','低质量reads比例', '长度过短reads比例', '含有adapter的reads比例', '去除的重复序列比例', '最终去除的reads比例', '宿主比例', 'IC比例', '非IC比例', 'Klebsiella pneumoniae_per','Listeria monocytogenes_per','Cryptococcus neoformans_per','Human gammaherpesvirus 4_per','Enterovirus A_per','Salmonella enterica_per']
    Arrange.sort_values(by= "sample", inplace = True)
    Arrange.to_csv(args.output, index = False, sep = "\t")


#output = {'total_reads': 0, 'passed_reads': 0, 'low_quality_reads': 0, 'too_short_reads': 0,
#          'adapter_trimmed_reads': 0}  # set the default values of each object
# generate the perent columns: data['qc_per'], data['qc2_per'] = data['qc1N']/data['rawRdN'], data['qc2N']/ data['rawRdN']
# method 1, transfer a float to str in percent: data['qc3_per'] = data['qc3_per'].apply(lambda x : str(x * 100)[0:4] + '%')
# method 2, transfer a float to str in percent:
# f = lambda x: '%.4f' % x save the float to a str with length 4
# data[['qc_per','qc2_per']] = data[['qc_per','qc2_per']].applymap(f) transfer the related columns
# data[['qc_per','qc2_per']] = data[['qc_per','qc2_per']].astype('float64') transfer to float again
# f1 = lambda x :'%.2f%%'  %  (x*100) define another function
# data[['qc_per','qc2_per']] = data[['qc_per','qc2_per']].applymap(f1)


