#! /bin/bash

bwa=$1;
index=$2;
input=$3;
threads=$4;

##$BWA1 $ot_dir/$ot_pre".unmap2.fastq" -t $THREAD | grep -v "@" - |awk -F"\t" '{if($3 == "*") print("@"$1"\n"$10"\n+\n"$11)}' > $ot_dir/$ot_pre".unmap3.fastq" 2> $ot_dir/$ot_pre".rmh4.log";
bwa mem $index $input -t $threads | grep -v "@" - |awk -F"\t" '{if($3 == "*") print("@"$1"\n"$10"\n+\n"$11)}'
