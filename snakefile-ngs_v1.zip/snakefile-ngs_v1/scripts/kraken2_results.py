import os, sys
import numpy as np
import pandas as pd
import re
import  argparse

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2_bracken result arrange based on abundance level.')
    parser.add_argument('--kraken', help='A bracken files directory as an input file.', nargs= "+", type=str, required=True)
    parser.add_argument('--abundance', help='A value set to filter the kraken species, default as 0.05.', default= 0.05, type = float)
    parser.add_argument("--samplelist", help = "A sample list file contains all the positive and negative samples list.", type = str, required=True)
    parser.add_argument('--output', help='An output file to save the results.', type=str, required=True)
#    parser.add_argument('--final', help='An output file to save the final normalized results.', type=str, required=True)

#    parser.add_argument('--output1', help='An output file to save final results, default as xlsx format.', type=str,
#                        required=True)
#    parser.add_argument("--output2", help="An output file to the blast statistic result.", type=str)
    #    parser.add_argument('--chimera', help="A directory contained all the chimera results.", type=str, required = True)
    #    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args
def single_sample(args1, para):
    df = pd.read_csv(args1, sep = "\t", usecols=[0,1,5,6])
    df.rename(columns={"name": "species", "taxonomy_id": "taxid", "new_est_reads": "reads", "abun_total_reads(%)": "abundance"}, inplace=True)
    df.rename(columns={"fraction_total_reads": "abundance"}, inplace=True)  ## a few special samples
    name = os.path.basename(args1).split(".")[0]
    df["sample"] = name
    result = df[df['abundance'] >= float(para)]
    return(result)
def main():
    args = parse_input()
    output = pd.DataFrame()
    samples = pd.read_csv(args.samplelist, header = None)[0].tolist()
    for i in args.kraken:
        for dirpath, dirname, files in os.walk(i):
            for fi in files:
                name = fi.split(".")[0]
                if fi.endswith("final.bracken") and name in samples:
                    result = single_sample(os.path.join(dirpath, fi), args.abundance)
                    output = pd.concat([output, result], sort = True)
#    output = output[["sample", "species", "taxid", "reads", "abundance"]]
    output = output[["sample", "species", "reads", "abundance"]]
    output.sort_values(by = ["sample", "abundance"], ascending= False, inplace= True)
#    output = output[~output["species"].isin(["Escherichia virus Lambda", "Escherichia virus MS2"])] #目前还需要IC的丰度来辅助判断，不可以删除这个数值
    output.to_csv(args.output, sep = "\t", index = False)
    return ("Finished the kraken results arrange.")
if __name__ == "__main__":
    main()

