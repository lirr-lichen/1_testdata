import pandas as pd
import os, sys, re

origin = pd.read_csv(sys.argv[1], sep = '\t', header = None)
refer = pd.read_csv(sys.argv[2], sep = '\t')
#refer.drop(['parent_taxid'], axis = 1, inplace = True)
labels = ['tag', 'length', 'number', 'match_length', 'seqid', 'species_length', 'start', 'end', 'region_length', 'taxid', 'species', 'genus','length2', 'bitscore']
Labels = {}
for i in range(len(labels)):
    Labels[i] = labels[i]
origin.rename(columns = Labels, inplace = True)
#origin.drop(['taxid', 'species','genus'],axis = 1, inplace = True)
origin.drop(['taxid', 'species', 'genus'],axis = 1, inplace = True)
result = pd.merge(origin, refer[['seqid','taxid', 'species', 'genus']], on = 'seqid')
#result.drop(['parent_taxid'], axis = 1, inplace = True)
result = result[labels]
result.to_csv(sys.argv[3], sep = '\t', index = False, header = None)
