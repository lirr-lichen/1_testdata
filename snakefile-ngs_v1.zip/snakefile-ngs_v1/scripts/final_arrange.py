import re
import copy
import os, sys
import pandas as pd

data = pd.read_excel(sys.argv[1], sheet_name="BigMatrix")
data = copy.deepcopy(data)
data = data[["mk", "taxid", "species_nano", "reads", "rlaPct", "genus", "superkingdom", \
             "reads_back", "reads_IC", "reads_BKIC", "RPM", "RPM_back", "RPM_IC", "RPM_BKIC", "libType", "MicroSum",
             "RPMSum", \
             "BM_rank", "brd_leak1", "mis_algn1", "brd_leak2", "mis_algn2", "pseudo_spe"]]
data.dropna(subset=["species_nano"], inplace=True)
data["Sample"] = data["mk"].apply(lambda x: x.split("ZFk_1_")[1])
data.rename(columns={"species_nano": "Species", "rlaPct": "Abundance", "reads": "Reads", "superkingdom": "物种分类"},
            inplace=True)
data["Cov1"], data["Cov1_ratio"], data["Cov2"], data["Cov2_ratio"] = -1, -1, -1, -1
data = data[["Sample", "taxid", "Species", "Reads", "Abundance", "Cov1", "Cov1_ratio", "Cov2", "Cov2_ratio", "物种分类"]]
taxdb = pd.read_csv(sys.argv[2], sep = "\t", usecols=["taxid", "species"])
del data["Species"]
result = pd.merge(data, taxdb[["taxid", "species"]], on = "taxid", how = "left")
result.rename(columns = {"species": "Species"}, inplace= True)
result = result[["Sample", "Species", "Reads", "Abundance","Cov1", "Cov1_ratio", "Cov2", "Cov2_ratio", "物种分类"]]
#data.to_csv(sys.argv[2], sep="\t", index=False)
result.to_csv(sys.argv[3], sep = "\t", index = False)
