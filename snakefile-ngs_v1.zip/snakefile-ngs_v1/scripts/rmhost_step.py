import os, sys
import pandas as pd
import subprocess
kraken2, centrifuge, bwa, bowtie2 = pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), pd.DataFrame()
for dirpath, dirname, files in os.walk(sys.argv[1]):
    for fi in files:
        if fi.endswith("unmap1.fastq"):
            name = fi.split(".")[0]
            line = subprocess.Popen("wc -l {}".format(os.path.join(dirpath, fi)), shell= True, stdout= subprocess.PIPE)
            ls = line.stdout.readline().strip().decode().split()
            data1 = {}
            data1["kraken2_reads"] = int(ls[0]) /4
            data1["sample"] = name
            result1 = pd.DataFrame(data1, index = [0])
            kraken2 = pd.concat([kraken2, result1], sort = True)
        if fi.endswith("unmap2.fastq"):
            name = fi.split(".")[0]
            line = subprocess.Popen("wc -l {}".format(os.path.join(dirpath, fi)), shell=True, stdout=subprocess.PIPE)
            ls = line.stdout.readline().strip().decode().split()
            data2 = {}
            data2["centrifuge_reads"] = int(ls[0]) / 4
            data2["sample"] = name
            result2 = pd.DataFrame(data2, index = [0])
            centrifuge = pd.concat([centrifuge, result2], sort=True)
        if fi.endswith("unmap3.fastq"):
            name = fi.split(".")[0]
            line = subprocess.Popen("wc -l {}".format(os.path.join(dirpath, fi)), shell=True, stdout=subprocess.PIPE)
            ls = line.stdout.readline().strip().decode().split()
            data3 = {}
            data3["bwa_reads"] = int(ls[0]) / 4
            data3["sample"] = name
            result3 = pd.DataFrame(data3, index = [0])
            bwa = pd.concat([bwa, result3], sort=True)
        if fi.endswith("unmap4.fastq"):
            name = fi.split(".")[0]
            line = subprocess.Popen("wc -l {}".format(os.path.join(dirpath, fi)), shell=True, stdout=subprocess.PIPE)
            ls = line.stdout.readline().strip().decode().split()
            data4 = {}
            data4["bowtie2_reads"] = int(ls[0]) / 4
            data4["sample"] = name
            result4 = pd.DataFrame(data4, index = [0])
            bowtie2 = pd.concat([bowtie2, result4], sort=True)
result = pd.merge( pd.merge(kraken2, centrifuge, on = "sample"), pd.merge(bwa, bowtie2, on = "sample"), on = 'sample')
result = result[["sample", "kraken2_reads", "centrifuge_reads", "bwa_reads", "bowtie2_reads"]]
result.sort_values(by = "sample", inplace= True)
result.to_excel(sys.argv[2], index = False)
