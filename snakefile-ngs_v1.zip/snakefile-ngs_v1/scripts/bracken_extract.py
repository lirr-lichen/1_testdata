import os, sys
import numpy as np
import pandas as pd
import re
import  argparse


def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2_bracken result NC relative abundance statistic.')
    parser.add_argument('--species', help='A directory of bracken results.', type=str, required=True)
    parser.add_argument('--genus', help='A directory bracken results.', type=str, required= True)
#    parser.add_argument('--NC', help='A series of NC bracken results', type = str, nargs= "+")
#    parser.add_argument("--nerve", help = "A file contains all the pathogen species of nerve and respiratory.", \
#                        type = str, default="/gpfsdata/users/liangxz/work/4.Respiratory_pathogen/15.pathogen_MySQL/mysql/3.medicalData/data/list_majian_addGramOxygen_20191216.txt")
#    parser.add_argument("--urinary", help = "A file contains all the pathogenic species of urinary system.", type = str, default="/gpfsdata/users/liangchen/codes/UrinaryPatho/data/pathogen_urinary")
#    parser.add_argument("--sampleinformation", help = "A sample information file contains all the samples needed information.", type=str, required=True)
#    parser.add_argument('--origin', help='An output to save original NC results.', type=str, required=True)
    parser.add_argument("--output1", help = "An output to save the final species level results.", type=str, required= True)
    parser.add_argument("--output2", help = "An output to save the final genus level results.", type=str, required= True)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args
def main():
    args = parse_input()
    result = pd.DataFrame()
    for dirpath, dirname, files in os.walk(args.species):
        for fi in files:
            if fi.endswith(".final.bracken"):
                name = fi.split(".")[0]
                df = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                df.rename(columns = {"name" : "species", "taxonomy_id" : "taxid", "new_est_reads" : "reads"}, inplace= True)
                df["sample"] = name
                output = df[["sample", "species", "taxid", "reads"]]
                result = pd.concat([result, output], sort = True)
    result = result[["sample", 'species', "taxid", "reads"]]
    result.sort_values(by="sample", inplace= True)
    result.to_excel(args.output1, index = False)
    result2 = pd.DataFrame()
    for dirpath, dirname, files in os.walk(args.genus):
        for fi in files:
            if fi.endswith(".final.bracken"):
                name = fi.split(".")[0]
                df = pd.read_csv(os.path.join(dirpath, fi), sep = "\t")
                df.rename(columns = {"name" : "genus", "taxonomy_id" : "taxid", "new_est_reads" : "reads"}, inplace= True)
                df["sample"] = name
                output = df[["sample", "genus", "taxid", "reads"]]
                result2 = pd.concat([result2, output], sort = True)
    result2 = result2[["sample", 'genus', "taxid", "reads"]]
    result2.sort_values(by="sample", inplace= True)
    result2.to_excel(args.output2, index = False)
    return ("Finished the work.")
if __name__ == "__main__":
    main()