import sys, os
import pandas as pd
import copy
import re



data = pd.read_excel(sys.argv[1])
data = copy.deepcopy(data[["sample", "total_bases", "total_reads", "qc3N", "rmhostN", "kraken_reads"]])
data["rawdata_per"] = data["total_bases"]/ data["total_bases"].sum()
data["Flt_per"] = data["qc3N"]/ data["total_reads"]
data["rmhost_per"] = data["rmhostN"] / data["total_reads"]
data["kraken_per"] = data["kraken_reads"]/ data["total_reads"]
for i in [ "rawdata_per","Flt_per", "rmhost_per", "kraken_per"]:
    data[i] = data[i].apply(lambda x : str(round(x * 100, 2)) + "%")
    for i in ["total_bases", "total_reads", "qc3N", "rmhostN", "kraken_reads"]:
        data[i + "_2"] = data[i].apply(lambda x : str(round(int(x) / (1000 * 1000), 3)) + "M")
result = pd.DataFrame()
result["Sample"] = data["sample"]
result["mdL"] = 75
result["mdQ"] = 30
result["Smp"] = data["total_bases_2"] + "/" + data["total_reads_2"] + "/" + data["rawdata_per"]
result["Flt"] = data["qc3N_2"] + "(" + data["Flt_per"] + ")"
result["Rmh"] = data["rmhostN_2"] + "(" + data["rmhost_per"] + ")"
result["Aln"] = data["kraken_reads_2"] + "(" + data["kraken_per"] + ")"
result = copy.deepcopy(result)
result.sort_values(by = "Sample", inplace=True)
sample = pd.read_csv(sys.argv[2], sep = "\t")
sample.rename(columns = {"libID": "Sample"}, inplace =True)
output = copy.deepcopy(pd.merge(result, sample[["Sample", "sampleID"]], on = "Sample", how = "left"))
del output["Sample"]
output.rename(columns = {"sampleID": "Sample"}, inplace = True)
output = output[["Sample", "mdL", "mdQ", "Smp", "Flt","Rmh","Aln"]]
output.to_csv(sys.argv[3], sep = "\t", index = False)
