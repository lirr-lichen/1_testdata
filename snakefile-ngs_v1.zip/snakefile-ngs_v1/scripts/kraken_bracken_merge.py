import argparse
import pandas as pd
import numpy as np
import os, sys
import copy

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2_bracken result add taxid, genus, superkingdom information.')
    parser.add_argument('--input', help='A series of kraken2/blast result files.', type=str, nargs= "+", required=True)
#    parser.add_argument('--taxDB', help='A file contained all the taxid_species_genus information.', type=str, default="/gpfsdata/users/zhangyan/NGS_database_20200510/reference/taxDB.tsv")
    parser.add_argument("--output", help = "An output to save the final results.", type=str, required= True)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)
    args = parser.parse_args()
    return args
def main():
    args = parse_input()
    result = pd.DataFrame()
    for fi in args.input:
        data = pd.read_csv(fi, sep = "\t")
        result = pd.concat([result, data], sort=True)
    result = copy.deepcopy(result)
    result.sort_values(by="sample", inplace=True)
    result = result[["sample", "species", "taxid", "genus", "superkingdom", "reads", "abundance"]]
    result.to_csv(args.output, sep="\t", index=False)
    return ("Finished the result merge and save.")

if __name__ == "__main__":
    main()