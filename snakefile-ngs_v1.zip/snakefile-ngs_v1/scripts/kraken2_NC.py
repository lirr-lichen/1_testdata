import os, sys
import numpy as np
import pandas as pd
import re
import  argparse

def parse_input():
    parser = argparse.ArgumentParser(description='This is a script for kraken2_bracken result NC relative abundance statistic.')
    parser.add_argument('--kraken', help='A bracken result as an input file.', type=str, required=True)
    parser.add_argument('--NC_IC', help='A series of NC_IC bracken results.', type=str, nargs= "+")
    parser.add_argument('--NC', help='A series of NC bracken results', type = str, nargs= "+")
    parser.add_argument('--output', help='An output file to save the results.', type=str, required=True)
#    parser.add_argument('--final', help='An output file to save the final normalized results.', type=str, required=True)

#    parser.add_argument('--output1', help='An output file to save final results, default as xlsx format.', type=str,
#                        required=True)
#    parser.add_argument("--output2", help="An output file to the blast statistic result.", type=str)
    #    parser.add_argument('--chimera', help="A directory contained all the chimera results.", type=str, required = True)
    #    parser.add_argument('-P', '--process', help = 'The process used in analysis.', type = int, default = 3)
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(1)

    args = parser.parse_args()
    return args
#def NC_average(*args):
#    result = pd.DataFrame()
#    for i in args:
#        data = pd.read_csv(args, sep = "\t", usecols=["name", "abun_total_reads(%)"])
#        data.rename(columns={"name":"species", "abun_total_reads(%)": "abundance"}, inplace = True)
#        result = pd.merge(result, data, on = "species", how= "outer")
#    result.fillna(0.0)
#    result.reset_index(result["species"], inplace = True)
#    del result["species"]
#    del result.index.name
#    result['mean'] = result.mean(axis = 1)
#    result.rename(columns= {"mean" : "abundance"}, inplace= True)
#    output = result[["species", "abundance"]]
#    return (output)
def NC_average(*args):
    output = {}
    for fi in args:
        for j in fi:
            f = open(j, 'r')
            f.readline()
            for line in f:
                line = line.strip()
                ls = line.split("\t")
#                print (ls[0] + "\t" + ls[-1])
                if ls[0] not in output:
                    output[ls[0]] = []
                output[ls[0]].append(float(ls[-1]))
            f.close()
    result = {}
    for j in output.keys():
        result[j] = np.mean(output[j])
    df = pd.DataFrame(result, index = [0]).T
    df.reset_index(inplace = True)
    df.rename(columns= {"index": "species", 0: "abundance"}, inplace = True)
    return(df)

def NC_normalization(kraken, NC_IC = None, NC = None):
    data = pd.read_csv(kraken, sep = "\t", usecols=[0, 1, 5, 6])
    data.rename(columns={"name": "species", "taxonomy_id": "taxid", "new_est_reads": "reads", "abun_total_reads(%)": "abundance"}, inplace=True)
    data.rename(columns={"fraction_total_reads": "abundance"}, inplace=True)  ## a few special samples
    result = ""
#    NC_IC_data = pd.DataFrame({"species" : None, "abundance" : None}, index = [0])
#    NC_data = pd.DataFrame({"species" :None, "abundance" : None}, index= [0])
    if NC_IC and not NC:
        NC_IC_data = NC_average(NC_IC)
        result = pd.merge(data, NC_IC_data, on="species", how="left")
        result.rename(columns={"abundance_x": "abundance", "abundance_y": "abundance_NC_IC"}, inplace=True)
        result["abundance_NC"] = None
        result["IC_ratio"] = result["abundance"] / result["abundance_NC_IC"]
        result["NC_ratio"] = None
        result.sort_values(by=["IC_ratio"], ascending=False, inplace=True)
    if NC and not NC_IC:
        NC_data = NC_average(NC)
        result = pd.merge(data, NC_data, on="species", how="left")
        result.rename(columns={"abundance_x": "abundance", "abundance_y": "abundance_NC"}, inplace=True)
        result["abundance_NC_IC"] = None
        result["IC_ratio"] = None
        result["NC_ratio"] = result["abundance"] / result["abundance_NC"]
        result.sort_values(by=["NC_ratio"], ascending=False, inplace=True)
    if NC_IC and NC:
        NC_IC_data = NC_average(NC_IC)
        NC = NC_average(NC)
        result1 = pd.merge(data, NC_IC_data, on = "species", how = "left")
        result = pd.merge(result1, NC, on = "species", how = "left")
        result.rename(columns= {"abundance_x": "abundance", "abundance_y" : "abundance_NC_IC", "abundance": "abundance_NC"}, inplace= True)
        result["IC_ratio"] = result["abundance"] / result["abundance_NC_IC"]
        result["NC_ratio"] = result["abundance"] / result["abundance_NC"]
        result.sort_values(by=["IC_ratio", "NC_ratio"], ascending=False, inplace=True)
    result = result[["species", "taxid", "reads", "abundance", "abundance_NC_IC", "abundance_NC", "IC_ratio", "NC_ratio"]]
#    result.to_csv(args.output, sep="\t", index=False)
    return (result)

def main():
    args = parse_input()
#    data = pd.read_csv(args.kraken, sep = "\t", usecols=[0, 1, 5, 6])
#    data.rename(columns={"name" : "species", "taxonomy_id": "taxid", "new_est_reads": "reads", "abun_total_reads(%)": "abundance"}, inplace= True)
#    data.rename(columns = {"fraction_total_reads" : "abundance"}, inplace=True) ## a few special samples
#    result = ""
    if args.NC_IC and not args.NC:
#        NC_IC_data = NC_average(args.NC_IC)
#        result = pd.merge(data, NC_IC_data, on="species", how="left")
#        result.rename(columns={"abundance_x": "abundance", "abundance_y": "abundance_NC_IC"}, inplace=True)
#        result["abundance_NC"] = None
#        result["IC_ratio"] = result["abundance"] / result["abundance_NC_IC"]
#        result["NC_ratio"] = None
#        result.sort_values(by=["IC_ratio"], ascending=False, inplace=True)
        result = NC_normalization(args.kraken, NC_IC=args.NC_IC)
    if args.NC and not args.NC_IC:
#        NC_data = NC_average(args.NC)
#        result = pd.merge(data, NC_data, on = "species", how = "left")
#        result.rename(columns= {"abundance_x": "abundance", "abundance_y" : "abundance_NC"}, inplace= True)
#        result["abundance_NC_IC"] = None
#        result["IC_ratio"] = None
#        result["NC_ratio"] = result["abundance"] / result["abundance_NC"]
#        result.sort_values(by=["NC_ratio"], ascending=False, inplace=True)
        result = NC_normalization(args.kraken, NC=args.NC)

    if args.NC_IC and args.NC:
        result = NC_normalization(args.kraken, NC_IC=args.NC_IC, NC=args.NC)
#        NC_IC_data = NC_average(args.NC_IC)
#        NC_data = NC_average(args.NC)
#        result1 = pd.merge(data, NC_IC_data, on = "species", how= "left")
#        result = pd.merge(result1, NC_data, on = "species", how = "left")
#        result.rename(columns= {"abundance_x": "abundance", "abundance_y" : "abundance_NC_IC", "abundance": "abundance_NC"}, inplace= True)
#        result["IC_ratio"] = result["abundance"] / result["abundance_NC_IC"]
#        result["NC_ratio"] = result["abundance"] / result["abundance_NC"]
 #       result.sort_values(by=["IC_ratio", "NC_ratio"], ascending=False, inplace=True)
#
#    result = result[["species", "taxid", "reads", "abundance", "abundance_NC_IC", "abundance_NC", "IC_ratio", "NC_ratio"]]
    result.sort_values(by=["IC_ratio", "NC_ratio"], ascending=False, inplace=True)
    result.to_csv(args.output, sep = "\t", index = False)

    return ("Finished analysis.")
if __name__  == "__main__":
    main()