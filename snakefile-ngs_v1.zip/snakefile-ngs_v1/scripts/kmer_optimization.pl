#!/usr/bin/perl

my($kraken, $threshold, $out, $taxdb_lineages) = @ARGV;

# taxonomy lineages
# my $taxdb_lineages="/gpfsdata/users/liangxz/work/20.NGS/db/taxonomy/taxDB.topo"; # taxonomy lineages
my (%lineages, %lineages_map);
&get_lineages($taxdb_lineages, \%lineages, \%lineages_map);

# kraken optimization
open IN,  $kraken|| die;
open OUT, ">$out"|| die;

while(<IN>){
    chomp;
    my($classify, $read_id, $taxid, $read_len, $kmers) = (split(/\t/))[0,1,2,3,4];
    my $total_kmers = $read_len - 35 + 1;
    
    if($classify eq "U"){
        print OUT "$classify\t$read_id\t$taxid\t$read_len\tP=0.000\t$kmers\n";
    }elsif($taxid eq "1"){
        print OUT "U\t$read_id\t0\t$read_len\tP=0.000\t$kmers\n";
    }else{
        my @kmer     = split(/\s/, $kmers);
        my @lineages = split(/\,/, $lineages{$taxid});
        #pop @lineages;
        #pop @lineages; # 至superkingdom level

        my (@kmer_taxid, %kmer_count);
        for (my $i = 0; $i < @kmer; $i ++){
            
            my ($kmer_taxid, $kmer_count) = (split(/\:/, $kmer[$i]))[0,1];
            $kmer_count{$kmer_taxid} += $kmer_count;

            if($kmer_taxid ne "0" && $kmer_taxid ne "A"){
                push @kmer_taxid, $kmer_taxid;
            }

        }

        my %uniq;
        @kmer_taxid  = grep {++ $uniq{$_} < 2} @kmer_taxid;
        #print $kmer_taxid[0]."\n";last;

        my %hash_a = map{$_=>1} @lineages;
        my %hash_b = map{$_=>1} @kmer_taxid;
        my %merge_all = map {$_ => 1} @lineages, @kmer_taxid;
        my @kmer_only = grep {!$hash_a{$_}} @kmer_taxid;
        my @common    = grep {$hash_a{$_}} @kmer_taxid;

        # aligned_kmer score
        my ($aligned_kmer, $unaligned_kmer);
        for (my $ki = 0; $ki < @common; $ki ++){
            $aligned_kmer += $kmer_count{$common[$ki]};    
        }
        my $unaligned_kmer = $kmer_count{"0"} + $kmer_count{"A"};
        my $score          = sprintf "%.3f",($aligned_kmer/$total_kmers)*(1-($unaligned_kmer/$total_kmers));

        if($score >= $threshold){
            print OUT "C\t$read_id\t$taxid\t$read_len\tP=$score\t$kmers\n";
        }else{
            print OUT "U\t$read_id\t0\t$read_len\tP=$score\t$kmers\n";
        }
    }
        
}
close IN;
close OUT;

#######
sub get_lineages{

    my($file, $hash1, $hash2) = @_;

    open TMP, $file || die;

    while(<TMP>){
        chomp;
        my($taxid, $lineages, $lineages_map) = (split(/\t/))[0,1,4];
        $$hash1{$taxid} = $lineages;
        $$hash2{$taxid} = $lineages_map;
    }
    close TMP;
}
