import os,sys
import argparse
import numpy as np
import pandas as pd
import json
import re
import yaml
import subprocess
import copy
import time

def NGS_generate(workdir, output, alldir, runid, mode = "SE", length = "75", IC_taxid = ["10710", "329852", "1921008"], final = "NGS.json"):
    result = {}
    result["configuration"] = {"length" : length, "mode" : mode, "IC_taxid": IC_taxid, "kraken2": "0.5", "bracken" : "1"}
    result["Runid"] = runid
    result["workdir"] = workdir
    result["output"] = output
    result["alldir"] = alldir   
    result["QC"]= os.path.join(workdir, "QC")
    result["rmhost"] = os.path.join(workdir, "rmhost")
    result["kraken"] = os.path.join(workdir, "kraken")
    result["blast"] = os.path.join(workdir, "blast")
    result["chimera"] = os.path.join(workdir, "chimera")
    result["html"] = os.path.join(output, "QC_html")
    result["origin"] = os.path.join(output, "origin")
    w = open(final, 'w')
    json.dump(result, w)
    w.close()
    return ("Finished the NGS.json generate.")

def samples_json_generate(rawdir, output):
    result = {}
    for dirpath, dirname, files in os.walk(rawdir):
        for fi in files:
            if "fastq" in fi or "fq" in fi:
                name = re.search("(.*?)\_S", fi).groups()[0]
                if name not in result:
                    result[name] = {"R1": [], "R2": []}
                if "R1" in fi and os.path.join(dirpath, fi) not in result[name]["R1"]:
                    size = os.path.getsize(os.path.join(dirpath, fi))
                    if size /(1000*1000) >= 1:
                        result[name]["R1"].append(os.path.join(dirpath, fi)) # SE analysis mode, only save the R1 fastq.gz
                    else:
                        del result[name]
    w = open(output, 'w')
    json.dump(result, w)
    w.close()
    return ("Finished the samples extract.")

def samples_list_generate(samplesheet, output):
    data = pd.read_excel(samplesheet, sheet_name = "样本说明", header = 1)
    data[["样本原始编号", "样本文库编号"]].to_csv(output, header = None, sep = '\t', index = False)
    return ("Finished the samples list generate.")
def samples_information(samplesheet, platform = "NGS550AR", sample_json = None, output = "output"):
    df = pd.read_csv(samplesheet)
    RunID = time.strftime("%Y%m%d", time.localtime())
    runtime = df[df["[Header]"] == "Experiment Name"].index
    if len(runtime) >= 1:
        RunID = df.iloc[runtime[0], 1]
    pos = df[df["[Header]"] == "Sample_ID"].index[0] + 1
    data = pd.read_csv(samplesheet, skiprows= pos)
    number = 1
    sample_list = None
    with open(sample_json) as f:
        samples = json.load(f)
        sample_list = list(samples.keys())
    Runid = RunID + "_" + platform + "_NJ" + "_ZFk" + "_" + str(number)
    result = {"RunID": RunID + "_" + platform + "_NJ" + "_ZFk" + "_" + str(number), "libID": [], "sampleID": [], "libType":[], "SampleType": []}
    for i in data["Sample_ID"].tolist():
        if i in sample_list:
            result["libID"].append(i)
    for i in result["libID"]:
        if i.startswith("PC") or i.startswith("NC"):
            result["sampleID"].append(i[0:-4])
            if i[-4] == "D":
                result["SampleType"].append("water_DNAIC")
                result["libType"].append("DNA")
            if i[-4] == "R":
                result["SampleType"].append("water_RNAIC")
                result["libType"].append("RNA")
        else:

            result["sampleID"].append(i[0:-6] + "_" + str(number))
            result["SampleType"].append(i[-6])
            if i[-4] == "D":
                result["libType"].append("DNA")
            if i[-4] == "R":
                result["libType"].append("RNA")
    result = pd.DataFrame(result, index = range(len(result["libType"])))
    result["SampleType"].replace({"A": "respiratory", "P": "respiratory", "Q": "CSF", "E": "CSF"}, inplace=True)
    result = result[["RunID", "sampleID", "libID", "SampleType", "libType"]]
    result.to_csv(output, sep = "\t", index = False)
    return (Runid)


def samplesheet_length(input):
    data = pd.read_csv(input)
    pos = data[data["[Header]"] == "[Reads]"].index[0] + 1
    length = str(int(data.iloc[pos, 0]) - 1)
    return (length)
def samples_check(sample, sample_infor, output):
#    data = pd.read_csv(samplesheet)
#    pos = data[data["[Header]"] == "Sample_ID"].index[0] + 1
#    end = data["[Header]"].count() + 1
#    samples_origin = data.iloc[start: end, 0].tolist()
#    df = pd.read_csv(samplesheet, skiprows= pos)
#    samples_origin = df["Sample_ID"].tolist()
    df = pd.read_csv(sample_infor, sep = "\t")
    samples_origin = df["libID"].tolist()
    sample = json.load(open(sample))
    w = open(output, 'w')
    w.write("##Sample\tRawdata\n")
    for i in samples_origin:
        if i in sample.keys():
            w.write(i + "\t" + "True" + "\n")
        else:
            w.write(i + "\t" + "Failed" + "\n")
    w.close()
    return ("Finished the samples check!")
def config_yaml_generate(samples, NGS, workflow, output):
    result = {}
    result["NGS"] = NGS
    result["SAMPLES"] = samples
    result["WORKFLOW"] = workflow
    w = open(output, 'w')
    yaml.dump(result, w, default_flow_style= False)
    w.close()
    return ("Finished the config yaml file generate!")
def runinformation(sampleinfor, output):
    data = pd.read_csv(sampleinfor, sep = "\t")
    RunID = data["RunID"].tolist()[0]
    result = {
	"runid": RunID, # 时间测序仪编号——试剂--医院简称--人员简称--上机次数
	"pipeline": "mNGS1.0", # 项目名称
	"total": "-1.0",
	"maxscan": "-1",
	"fc": "--",
	"minL": "75",
	"minQ": "30",
	"category": "Operation",
	 "Samples": {
	 	"mCNS2020": {
	 	#	"BC06": ["20200715test1", "sputum", "A", "1", "0", "0", "100", "78.3", ""],
            }
     },
    "hospital": "南京医院",
    "gridon_NO": RunID.split("_")[1],
    "samplenum": 1,
    "date": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())}
    location = 1
    df = data[~data["sampleID"].isin(["-1111", -1111])]
    for i in df["sampleID"].tolist():
        label = "BC"
        if location < 10:
            label = "BC" + "0" + str(location)
        else:
            label = "BC" + str(location)
        if label not in result["Samples"]["mCNS2020"]:
            result["Samples"]["mCNS2020"][label] = None
        ls = [i, "sputum", "A", "1", "0", "0", "100", "78.3", ""]
        result["Samples"]["mCNS2020"][label] = ls
        location += 1
    w = open(output, "w")
    json.dump(result, w)
    w.close()
    return (True)

