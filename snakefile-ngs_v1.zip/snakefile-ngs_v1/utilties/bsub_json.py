import json
import os, sys
import subprocess

def bsub_json(workdir, execute ="/bin/bash", time = 6, nCPUs = 24, memory = 120000):
    """This is a function to generate the bsub.json to the specified destination. only output directory is needed."""
    result = {}
    result["execute"] = execute
    if time < 10:
        result["time"] = "0" + str(time) + ":00:00"
    if time >=10:
        result["time"] = str(time) + ":00:00"
    result["nCPUs"] = str(nCPUs)
    result["memory"] = memory
    result["resources"] =  "\"rusage[mem=100000] span[hosts=1]\""
    #result["name"] = "snake_{rule}_{wildcards}"
    #result["output"] = os.path.join(workdir, "logs_{rule}_{wildcards}.out")
    #result["error"] = os.path.join( workdir, "logs_{rule}_{wildcards}.err")
    result["name"] = "snakemake_NGS"
    result["output"] = os.path.join(workdir, "bsub.out")
    result["error"] = os.path.join( workdir, "bsub.err")    
#    output = {"__default__" : result}
#    return (output)
    return (result)
