import os, sys
import json
import yaml
import numpy as np
import pandas as pd
#PBS -N bowtie2
#PBS -l nodes=1: ppn=20
#PBS -j oe
def qsub_json(workdir, time = 120, nCPUs = 24, memory = "180g", node = 3, name = "snakemake_NGS"):
    """This is a function to generate the bsub.json to the specified destination. only output directory is needed."""
    result = {}
#    result["execute"] = execute
    if time < 10:
        result["walltime"] = "walltime:" + "0" + str(time) + ":00:00"
    if time >=10:
        result["walltime"] =  "walltime:" + str(time) + ":00:00"
    result["node"] = "node=" + str(node) + ":ppn=" +  str(nCPUs)
    result["memory"] = "mem=" + memory
#    result["resources"] =  "\"rusage[mem=100000] span[hosts=1]\""
    #result["name"] = "snake_{rule}_{wildcards}"
    #result["output"] = os.path.join(workdir, "logs_{rule}_{wildcards}.out")
    #result["error"] = os.path.join( workdir, "logs_{rule}_{wildcards}.err")
    result["name"] = name
    result["output"] = os.path.join(workdir, "qsub.out")
    result["error"] = os.path.join( workdir, "qsub.err")
#    output = {"__default__" : result}
#    return (output)
    return (result)